<?php

session_start();

$server = 'localhost';
$user = 'root';
$password = '';
$database = 'php_crud';

try {
    $conn = new PDO("mysql:host=$server;dbname=$database;", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}