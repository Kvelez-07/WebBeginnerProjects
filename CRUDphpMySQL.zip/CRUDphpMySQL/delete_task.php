<?php

require_once 'database.php';

if(isset($_REQUEST['id'])) {
    $id = $_REQUEST['id'];
    $sql = "DELETE FROM tasks WHERE id = $id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    $_SESSION['message'] = 'Task deleted successfully';
    $_SESSION['message_type'] = 'success';
    header('Location: index.php');
    exit();

    if(!$stmt->execute()) {
        $_SESSION['message'] = 'Task could not be deleted';
        $_SESSION['message_type'] = 'danger';
        header('Location: index.php');
        exit();
    }
}