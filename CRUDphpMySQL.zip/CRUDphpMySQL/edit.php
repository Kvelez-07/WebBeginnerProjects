<?php

require_once 'database.php';

if(isset($_REQUEST['id'])) {
    $id = $_REQUEST['id'];
    $sql = "SELECT * FROM tasks WHERE id = $id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    if($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $title = $row['title'];
        $description = $row['description'];
    }
}

if(isset($_REQUEST['update'])) {
    $id = $_REQUEST['id'];
    $title = $_REQUEST['title'];
    $description = $_REQUEST['description'];
    $sql = "UPDATE tasks SET title = ?, description = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$title, $description, $id]);
    header('location: index.php');

    if ($stmt->rowCount() > 0) {
        $_SESSION['message'] = 'Task updated successfully';
        $_SESSION['message_type'] = 'success';
        header('location: index.php');
        exit(0);
    } else {
        $_SESSION['message'] = 'Task not updated';
        $_SESSION['message_type'] = 'danger';
        header('location: index.php');
        exit(0);
    }
}

?>

<?php include_once 'includes/header.php'; ?>

<div class="container p-4">
    <div class="row">
        <div class="col-md-4 mx-auto">
            <div class="card card-body">
                <form action="edit.php?id=<?= $_REQUEST['id'] ?>" method="post">
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <input type="text" name="title" value="<?= $title ?>" class="form-control" placeholder="Task Title">
                    </div> <br>
                    <div class="form-group">
                        <textarea name="description" rows="2" class="form-control" placeholder="Update Description"><?= $description ?></textarea>
                    </div> <br>
                    <button type="submit" class="btn btn-success btn-block" name="update">Update</button> 
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>