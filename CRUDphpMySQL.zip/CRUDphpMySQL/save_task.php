<?php

require_once 'database.php';

if(isset($_REQUEST['save_task'])) {
    $title = $_REQUEST['title'];
    $description = $_REQUEST['description'];

    try {
        $sql = "INSERT INTO tasks (title, description) VALUES (:title, :description)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':description', $description);
        $stmt->execute();

        $_SESSION['message'] = 'Task saved successfully';
        $_SESSION['message_type'] = 'success';
        
        header ("Location: index.php");
        exit();

    } catch(PDOException $e) {
        die ("ERROR: " . $e->getMessage());
    }

}