const display = document.getElementById("display"); // Get the display element

function appendToDisplay(value) {
    display.value += value; // Append the value to the display
}

function clearDisplay() {
    display.value = ""; // Clear the display
}

function calculate() {
    try{
        display.value = eval(display.value); // Evaluate the expression and display the result
    }
    catch(err){
        display.value = "Error"; // Display error message
    }
}