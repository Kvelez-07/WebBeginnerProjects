let character = document.getElementById("character");
let block = document.getElementById("block");
let scoreBoard = document.getElementById("score");
let score = 0;
let isGameOver = false;

function jump() {
    if(character.classList != "animate") {
        character.classList.add("animate");
    }
    setTimeout(function() {
        character.classList.remove("animate");
    }, 600);

    score++;
    scoreBoard.innerHTML = `Score: ${score}pts`;
}

let collision = setInterval(() => {
    let characterTop = parseInt(window.getComputedStyle(character).getPropertyValue("top"));
    let blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"));

    if (blockLeft < 20 && blockLeft > 0 && characterTop >= 130) {
        block.style.animation = "none";
        block.style.display = "none";
        alert(`Gamer over. Score: ${score}`);
        window.location.reload();
    }
}, 10);