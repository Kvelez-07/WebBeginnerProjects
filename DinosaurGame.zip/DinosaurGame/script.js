// environment
let board;
let boardWidth = 750;
let boardHeight = 250;
let context;

// dinosaur
let dinoWidth = 88;
let dinoHeight = 94;
let dinoX = 50;
let dinoY = boardHeight - dinoHeight; // default position
let dinoImage;

// dinosaur object
let dino = {
    x: dinoX,
    y: dinoY,
    width: dinoWidth,
    height: dinoHeight,
}

// cactus
let cactusArray = [];
let cactus1Width = 34;
let cactus2Width = 69;
let cactus3Width = 102;

let cactusHeight = 70; // same height
let cactusX = 700; // cactus spawn coordinates
let cactusY = boardHeight - cactusHeight;

let cactusImage1; // cactus images
let cactusImage2;
let cactusImage3;

// dynamics
let velocityX = -8; // left speed
let velocityY = 0; // ground the dino
let gravity = 1.5; // gravity

let isGameOver = false;
let dinoScore = 0;

window.onload = function() {
    board = document.getElementById('board');
    board.height = boardHeight;
    board.width = boardWidth;

    context = board.getContext('2d'); // 2d drawing
    dinoImage = new Image(); // image
    dinoImage.src = './img/dino.png'; // image source

    dinoImage.onload = function() {
        context.drawImage(dinoImage, dino.x, dino.y, dino.width, dino.height);
    }

    cactusImage1 = new Image(); // cacti images
    cactusImage1.src = './img/cactus1.png'

    cactusImage2 = new Image();
    cactusImage2.src = './img/cactus2.png'
    
    cactusImage3 = new Image();
    cactusImage3.src = './img/cactus3.png'


    
    requestAnimationFrame(update); // call update
    setInterval(drawCactus, 1000); // call drawCactus every second
    document.addEventListener('keydown', dinoMotion); // dino motion
}

function update() {
    requestAnimationFrame(update);

    context.clearRect(0, 0, boardWidth, boardHeight); // clear canvas to spawn only one cactus

    // repetitive draw per frame
    velocityY += gravity; // gravity
    dino.y = Math.min(dino.y + velocityY, dinoY); // move dino down by velocityY
    context.drawImage(dinoImage, dino.x, dino.y, dino.width, dino.height);

    // move cactus
    for (let i = 0; i < cactusArray.length; i++) {
        let cactus = cactusArray[i]; // current cactus
        cactus.x += velocityX; // move cactus right by 8
        context.drawImage(cactus.img, cactus.x, cactus.y, cactus.width, cactus.height);

        if (dinoCollision(dino, cactus)) {
            isGameOver = true; // game over
            dinoImage.src = './img/dino-dead.png';
            dinoImage.onload = function() {
                context.drawImage(dinoImage, dino.x, dino.y, dino.width, dino.height); // draw dead dino
            }
        }
    }

    context.fillStyle = 'black';
    context.font = '20px Helvetica';
    dinoScore++; // increment score
    context.fillText(`Score: ${dinoScore}`, 5, 20); // display score
}

function dinoMotion(event) {
    if (isGameOver) {
        // stop dinosaur and stop motion
        window.alert(`Game Over. Your score: ${dinoScore}, try again?`);
        if (event.key == 'Enter') {
            location.reload(); // reload page
        }
        return;
    }

    if ((event.key == 'ArrowUp' || event.key == 'Space') && dino.y == dinoY) {
        // current position of dino for jump
        velocityY = -25; // jump
    }
}

function drawCactus() {
    let cactus = {
        img: null, // varies based on cactus type
        x: cactusX,
        y: cactusY,
        width: null, // varies based on cactus type
        height: cactusHeight
    }

    let randomCactus = Math.floor(Math.random() * 3) + 1; // 3 types of cactus

    if (randomCactus > .90) {
        // 10% chance of cactus type 3
        cactus.img = cactusImage3;
        cactus.width = cactus3Width;
        cactusArray.push(cactus); // add cactus to array
    } else if (randomCactus > .70) {
        // 30% chance of cactus type 2
        cactus.img = cactusImage2;
        cactus.width = cactus2Width;
        cactusArray.push(cactus); // add cactus to array
    } else if (randomCactus > .50) {
        // 50% chance of cactus type 1
        cactus.img = cactusImage1;
        cactus.width = cactus1Width;
        cactusArray.push(cactus); // add cactus to array
    }

    if (cactusArray.length > 5) { // slow down cactus spawning
        cactusArray.shift(); // remove first cactus in array to save memory
    }
}

function dinoCollision(a, b) {
    // collision detection for dino and obstacle
    return (a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y);
}