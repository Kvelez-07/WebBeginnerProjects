from django.contrib import admin
from .models import TodoItem

# $ python manage.py createsuperuser
# Username (leave blank to use 'kvele'): kvelez
# Email address: kvelezsalazar07@gmail.com
# Password: 
# Password (again): 
# Superuser created successfully.

# Register your models here.
admin.site.register(TodoItem) # This will allow you to see the TodoItem model in the Django admin panel