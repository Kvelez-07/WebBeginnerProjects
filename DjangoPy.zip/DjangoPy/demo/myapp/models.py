from django.db import models

# Create your models here.
# Django has a ORM (Object Relational Mapper) that allows you to create database tables

# Model migrations to SQLite database
# python manage.py makemigrations
# python manage.py migrate
class TodoItem(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    completed = models.BooleanField(default=False)