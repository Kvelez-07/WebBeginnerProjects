from django.shortcuts import render, HttpResponse
from .models import TodoItem

# Create your views here.
def home(request):
    return render(request, 'home.html') # inside templates folder

def about(request):
    return HttpResponse("About Page")

def contact(request):
    return HttpResponse("Contact Page")

def todos(request):
    todos = TodoItem.objects.all() # Query all the todo items from the database
    return render(request, 'todos.html', {'todos': todos}) # dictionary