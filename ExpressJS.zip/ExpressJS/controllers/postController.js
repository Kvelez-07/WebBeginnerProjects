let posts = [
    {
        id: 1,
        title: 'Hello World',
        body: 'This is my first post'
    },
    {
        id: 2,
        title: 'Hello World 2',
        body: 'This is my second post'
    }
];

// @desc Get posts
// @route GET /api/posts
// @access Public
export const getPosts = (req, res, next) => {
    const { limit } = parseInt(req.query.limit) || 10;
    if (!isNaN(limit) && limit > 0) {
        const error = new Error(`Limit must be a positive number`);
        error.status = 400;
        return next(error);
    }
    res.status(200).json(posts);
}

// @desc Get single post
// @route GET /api/posts/:id
// @access Public
export const getPost = (req, res, next) => {
    const { id } = req.params; // req.params.id
    const post = posts.find(p => p.id == id);
    if (!post || post.id != id) {
        const error = new Error(`Post with id ${id} not found`);
        error.status = 404;
        return next(error);
    }
    res.status(200).json(post);
}

// @desc Create post
// @route POST /api/posts
// @access Public
export const createPost = (req, res, next) => {
    const { title, body } = req.body;
    const post = { id: posts.length + 1, title, body };
    if (!post || !post.id || !title || !body) {
        const error = new Error(`Post not created`);
        error.status = 400;
        return next(error);
    }
    posts.push(post);
    res.status(201).json(post);
}

// @desc Update post
// @route PUT /api/posts/:id
// @access Public
export const updatePost = (req, res, next) => {
    const { id } = req.params;
    const { title, body } = req.body;
    const post = posts.find(p => p.id == id);
    if (!post || post.id != id || !title || !body) {
        const error = new Error(`Post with id ${id} not found`);
        error.status = 404;
        return next(error);
    }
    post.title = title;
    post.body = body;
    res.status(200).json(post);
}

// @desc Delete post
// @route DELETE /api/posts/:id
// @access Public
export const deletePost = (req, res, next) => {
    const { id } = req.params;
    const post = posts.find(p => p.id == id);
    if (!post) {
        const error = new Error(`Post with id ${id} not found`);
        error.status = 404;
        return next(error);
    }
    const index = posts.indexOf(post);
    posts.splice(index, 1);
    res.status(200).json({ message: "Post deleted successfully" });
}
