import colors from 'colors';

const logger = (req, res, next) => {
    const colorsMethod = {
        'GET': colors.blue,
        'POST': colors.green,
        'PUT': colors.yellow,
        'DELETE': colors.red
    }
    const color = colorsMethod[req.method];
    console.log(`${req.method} ${req.protocol}://${req.get('host')}${req.originalUrl}`[color]);
    next(); // go to the next middleware
}

export default logger;