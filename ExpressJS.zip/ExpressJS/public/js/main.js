const output = document.querySelector('#output');
const getPostsBtn = document.querySelector('#get-posts-btn');

const showPosts = async () => {
    try {
        const res = await fetch('http://localhost:8000/api/posts');
        if (!res.ok) {
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        const posts = await res.json();
        output.innerHTML = JSON.stringify(posts);
        posts.forEach(post => {
            const postEl = document.createElement('div');
            postEl.textContent = post.title;
            output.appendChild(postEl);
        });
    } catch (error) {
        console.log(`Error fetching posts: ${error}`);
    }
};

const createPost = async (e) => {
    e.preventDefault();
    const formData = new FormData(this);
    const title = formData.get('title');
    const body = formData.get('body');
    const post = { title, body };
    const res = await fetch('http://localhost:8000/api/posts', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(post)
    });
    if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
    }
    const data = await res.json();
    const postEl = document.createElement('div');
    postEl.textContent = data.title;
    output.appendChild(postEl);
};

// Event Listeners
getPostsBtn.addEventListener('click', showPosts);