import express from 'express';
import { createPost, deletePost, getPost, getPosts, updatePost } from '../controllers/postController.js';
const router = express.Router();

// GET request
router.get('/', getPosts);

router.get('/:id', getPost);

// POST request
router.post("/", createPost);

// PUT request
router.put("/:id", updatePost);

// DELETE request
router.delete("/:id", deletePost);

export default router; // export router