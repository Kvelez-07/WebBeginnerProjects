import express from 'express'; // type module
import path from 'path';
import { fileURLToPath } from 'url';
import posts from './routes/posts.js';
import logger from './middleware/logger.js';
import errorHandler from './middleware/error.js';
import notFound from './middleware/notFound.js';
const port = process.env.PORT || 8000;

// Static files Directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// static server, specify .html in the url
app.use(express.static(path.join(__dirname, 'public')))

// Body Parser Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Logger Middleware
app.use(logger);

// Routes
app.use('/api/posts', posts);

app.use((req, res, next) => {
    const error = new Error('Not Found');
    error.status = 404;
    next(error);
})

// Error Handler Middleware
app.use(errorHandler);

// Not Found Middleware
app.use(notFound);

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
