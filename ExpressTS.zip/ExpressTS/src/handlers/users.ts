import { Request, Response } from 'express';
import { CreateUserDTO } from '../dtos/createUserDTO';
import { CreateUserQueryParams } from '../types/query-params';
import { User } from '../types/response';

export const helloWorld = (req: Request, res: Response) => {
    res.send("Hello World!");
};

export const getUsers = (req: Request, res: Response) => {
    res.send("Hello Kvelez07!");
};

export const getUserById = (req: Request, res: Response) => {
    res.send(`User ID: ${req.params.id}`);
};

export const createUser = (req: Request<{}, {}, CreateUserDTO, CreateUserQueryParams>, res: Response<User>) => {
    res.status(201).send({
        id: 1,
        name: req.body.name,
        email: req.body.email
    })
}