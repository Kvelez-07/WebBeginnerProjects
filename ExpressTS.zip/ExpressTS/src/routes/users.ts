import { Router } from "express";
import { createUser, getUserById, getUsers, helloWorld } from "../handlers/users";

const router = Router();

// GET
router.get("/", helloWorld);
router.get("/api/v1/users", getUsers);
router.get("/:id", getUserById);

// POST
router.post("/api/v1/users", createUser);

export default router;
