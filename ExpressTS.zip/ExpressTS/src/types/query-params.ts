export interface CreateUserQueryParams {
    loginAfterSignup?: boolean;
}