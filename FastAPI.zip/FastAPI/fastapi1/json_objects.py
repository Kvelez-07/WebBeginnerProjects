from typing import Optional
from pydantic import BaseModel

inventory = {
    1: {
        "name": "Milk",
        "price": 2.5,
        "brand": "Nestle",
        "net_content": "1L"
    },
    2: {
        "name": "Bread",
        "price": 1.5,
        "brand": "Britannia",
        "net_content": "500g"
    }
}

services = {
    1: {
        "name": "Delivery",
        "price": 5
    },
    2: {
        "name": "Pickup",
        "price": 0
    }
}

careers = {
    1: {
        "name": "Software Engineer",
        "location": "London"
    },
    2: {
        "name": "Data Scientist",
        "location": "New York"
    }
}

class Item(BaseModel):
    name: str
    price: float
    brand: Optional[str] = None

class UpdateItem(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    brand: Optional[str] = None