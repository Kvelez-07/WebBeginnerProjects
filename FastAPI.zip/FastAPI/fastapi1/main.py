from fastapi import FastAPI, HTTPException, status
from typing import Optional
from json_objects import *

# Swagger UI: http://localhost:8000/docs

# Run in terminal: uvicorn main:app --reload
app = FastAPI()

# Endpoints
@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.get("/services")
async def get_services():
    return [service for service in services.values()]

@app.get("/services/{service_id}")
async def get_service(service_id: Optional[int] = None): # This is an optional parameter
    return services.get(service_id, {"message": HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Service not found")})

@app.get("/services-by-name/{service_name}")
async def get_service_by_name(service_name: Optional[str] = None): # This is an optional parameter
    return [service for service in services.values() if service["name"] == service_name]

@app.get("/products")
async def get_products():
    return [product for product in inventory.values()]

@app.get("/products/{product_id}")
async def get_product(product_id: int): # Optional[int] = None
    return inventory.get(product_id, {"message": HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")})

@app.get("/products-by-name/{product_name}")
async def get_product_by_name(product_name: str): # Optional[str] = None
    return [product for product in inventory.values() if product["name"] == product_name]

@app.get("/careers")
async def get_careers():
    return [career for career in careers.values()]

@app.get("/careers/{career_id}")
async def get_career(career_id: int): # Optional[int] = None
    return careers.get(career_id, {"message": HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Career not found")})

@app.get("/careers-by-location/{location}")
async def get_careers_by_location(location: str): # Optional[str] = None
    return [career for career in careers.values() if career["location"] == location]

@app.get("/all-data")
async def get_all_data():
    return {
        "products": [product for product in inventory.values()],
        "services": [service for service in services.values()],
        "careers": [career for career in careers.values()]
    }

@app.post("/create-product/{product_id}")
async def create_product(product_id: int, product: Item):
    if product_id in inventory:
        return {"message": HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Product already exists")}
    inventory[product_id] = product # Temporary storage
    return {"message": HTTPException(status_code=status.HTTP_201_CREATED, detail="Product created")}

@app.put("/update-product/{product_id}")
async def update_product(product_id: int, product: UpdateItem):
    if product_id not in inventory:
        return {"message": HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")}
    inventory[product_id] = product
    return {"message": HTTPException(status_code=status.HTTP_200_OK, detail="Product updated")}

@app.delete("/delete-product/{product_id}")
async def delete_product(product_id: int):
    if product_id not in inventory:
        return {"message": HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")}
    del inventory[product_id]
    return {"message": HTTPException(status_code=status.HTTP_200_OK, detail="Product deleted")}
