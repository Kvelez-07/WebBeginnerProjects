from typing import List
from uuid import uuid4
from fastapi import FastAPI, HTTPException, status
from models import Gender, Roles, User

# Run in terminal: uvicorn main:app --reload
# Swagger UI: http://localhost:8000/docs

app = FastAPI()

db: List[User] = [
    User(
        id=uuid4(),
        first_name="John",
        last_name="Doe",
        middle_name="M",
        gender=Gender.male,
        roles=[Roles.student]
    ),
    User(
        id=uuid4(),
        first_name="Jane",
        last_name="Doe",
        middle_name="M",
        gender=Gender.female,
        roles=[Roles.user]
    )
]

@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.get("/api/v1/users")
async def fetch_users():
    return db

@app.post("/api/v1/users")
async def register_user(user: User): # request body
    user.id = uuid4() # generate unique id (automatically)
    db.append(user) # append new user
    return {"id": user.id} # 201 Created

@app.put("/api/v1/users/{user_id}")
async def update_user(user_id: str, user: User):
    [db.remove(user) for user in db if user.id == user_id]
    user.id = user_id
    db.append(user)
    return {"message": HTTPException(status_code=status.HTTP_204_NO_CONTENT, detail="User updated successfully")}

@app.delete("/api/v1/users/{user_id}")
async def delete_user(user_id: str):
    [db.remove(user) for user in db if user.id == user_id]
    return {"message": HTTPException(status_code=status.HTTP_204_NO_CONTENT, detail="User deleted successfully")}