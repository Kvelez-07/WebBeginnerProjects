from fastapi import Body, FastAPI, HTTPException, Path
from models import Student, UpdateStudent, students

# Run in terminal: uvicorn main:app --reload
# Swagger UI: http://127.0.0.1:8000/docs

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "GET request successful!"}

@app.get("/get-students")
async def get_students():
    return students

@app.get("/get-student/{student_id}")
async def get_student(student_id: int = Path(..., description="The ID of the student you want to view", gt=0)):
    if student_id in students:
        return students[student_id]
    raise HTTPException(status_code=404, detail="Student not found")

@app.get("/get-student-by-name/{student_name}")
async def get_student_by_name(student_name: str = Path(..., description="The name of the student you want to view")):
    for student_id in students:
        if students[student_id].name == student_name:
            return students[student_id]
    raise HTTPException(status_code=404, detail="Student not found")

@app.post("/create-student")
async def create_student(student: Student = Body(...)):
    new_id = max(students.keys()) + 1 if students else 1
    student.id = new_id
    students[new_id] = student
    return students[new_id]

@app.put("/update-student/{student_id}")
async def update_student(student_id: int = Path(..., description="The ID of the student you want to update", gt=0), updated_student: UpdateStudent = Body(...)):
    if student_id in students:
        student = students[student_id]
        if updated_student.name is not None:
            student.name = updated_student.name
        if updated_student.last_name is not None:
            student.last_name = updated_student.last_name
        if updated_student.age is not None:
            student.age = updated_student.age
        students[student_id] = student
        return students[student_id]
    raise HTTPException(status_code=404, detail="Student not found")

@app.delete("/delete-student/{student_id}")
async def delete_student(student_id: int = Path(..., description="The ID of the student you want to delete", gt=0)):
    if student_id in students:
        del students[student_id]
        return {"message": "Student deleted successfully"}
    raise HTTPException(status_code=404, detail="Student not found")
