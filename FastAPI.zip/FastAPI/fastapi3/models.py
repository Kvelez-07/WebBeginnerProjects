from pydantic import BaseModel
from typing import Optional, Dict

class Student(BaseModel):
    id: int
    name: str
    last_name: str
    age: int

class UpdateStudent(BaseModel):
    name: Optional[str] = None
    last_name: Optional[str] = None
    age: Optional[int] = None

students: Dict[int, Student] = {
    1: Student(id=1, name="John", last_name="Doe", age=25),
    2: Student(id=2, name="Jane", last_name="Doe", age=26),
}
