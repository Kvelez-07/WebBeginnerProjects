from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from os import path

# Initialize database
db = SQLAlchemy()
DB_NAME = 'database.db' # TODO: Set a database name

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'your_secret_key_here' # TODO: Set a secret key
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_NAME}' # TODO: Set a database URI
    db.init_app(app) # Initialize the database

    from .auth import auth
    from .views import views

    # Register blueprints
    app.register_blueprint(views, url_prefix='/views')
    app.register_blueprint(auth, url_prefix='/auth')

    from .models import User, Note
    create_database(app)

    # Initialize LoginManager
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login' # Set the login view
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id): # Load user by ID
        return User.query.get(int(user_id))

    return app

def create_database(app):
    if not path.exists('website/' + DB_NAME):
        with app.app_context():
            db.create_all()
