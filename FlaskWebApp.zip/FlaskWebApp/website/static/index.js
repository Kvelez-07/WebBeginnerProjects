const deleteNote = (id) => {
    fetch('/delete-note', {
        method: 'POST',
        body: JSON.stringify({ 'noteId': id }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then((_res) => {
        window.location.href = '/views/home';
    })
}
