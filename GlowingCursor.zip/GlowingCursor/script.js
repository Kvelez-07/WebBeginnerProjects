let cursor = document.querySelector('#cursor');
let body = document.querySelector('body');

document.addEventListener('mousemove', (e) => {
    body.style.backgroundPositionX = e.clientX/-4 + 'px';
    body.style.backgroundPositionY = e.clientY/-4 + 'px';
    cursor.style.top = e.clientY + 'px';
    cursor.style.left = e.clientX + 'px';
})