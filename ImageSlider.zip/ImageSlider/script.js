const slides = document.querySelectorAll('.slide'); // Select all slides
const next = document.querySelector('.next'); // Select next button
const prev = document.querySelector('.prev'); // Select prev button
let slideIndex = 0; // Slide index
let intervalId = null; // Initialize interval id

document.addEventListener('DOMContentLoaded', initializeSlider); // Initialize slider on page load

function initializeSlider(){
    if (slides.length > 0){
        slides[slideIndex].classList.add('displaySlide'); // Add displaySlide class to the first slide
        intervalId = setInterval(nextSlide, 3000); // Call nextSlide every 3 seconds
    } else {
        console.log('No slides found'); // Log error message
    }
}

function showSlide(index){

    if (index >= slides.length){
        slideIndex = 0; // Reset slide index
    } else if(index < 0){
        slideIndex = slides.length - 1; // Reset slide index
    }

    slides.forEach(slide => {
        slide.classList.remove('displaySlide'); // Remove displaySlide class
    });

    slides[slideIndex].classList.add('displaySlide'); // Add displaySlide class to the current slide
}

function prevSlide(){
    clearInterval(intervalId); // Clear the interval
    slideIndex--;
    showSlide(slideIndex); // Show the previous slide
}

function nextSlide(){
    slideIndex++;
    showSlide(slideIndex); // Show the next slide
}