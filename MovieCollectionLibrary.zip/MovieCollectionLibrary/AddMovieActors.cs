﻿namespace MovieCollectionLibrary
{
    public interface IAddMovieActorsFactory
    {
        AddMovieActors CreateAddMovieActors(IUserRegistration userRegistration);
    }

    public class AddMovieActorsFactory : IAddMovieActorsFactory
    {
        public AddMovieActors CreateAddMovieActors(IUserRegistration userRegistration)
        {
            return new AddMovieActors(userRegistration);
        }
    }

    public class AddMovieActors : IPerson, IMovieActors
    {
        public string FullName { get; set; }
        public string BirthYear { get; set; }
        public string Score { get; set; }
        public string Country { get; set; }
        public string MovieTitle { get; set; }
        public string ActorData { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration;

        // Eenforce factory method usage
        public AddMovieActors(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public static AddMovieActors Create(IUserRegistration userRegistration)
        {
            return new AddMovieActors(userRegistration);
        }

        public void Actors()
        {
            try
            {
                _userRegistration.Register();
                FileName = $"{_userRegistration.UserName}.txt";
                FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

                Console.Write("\nEnter Movie Title: ");
                MovieTitle = Console.ReadLine().ToLower().Trim();

                // Check if the movie already exists in the file
                if (File.Exists(FilePath))
                {
                    string[] lines = File.ReadAllLines(FilePath);

                    int index = Array.FindIndex(lines, line => line.StartsWith(MovieTitle + ";", StringComparison.OrdinalIgnoreCase));

                    if (index != -1)
                    {
                        // Check if the movie already has 4 actors
                        if (lines[index].Split(';').Length - 4 >= 4)
                        {
                            Console.WriteLine($"The movie '{MovieTitle}' already has 4 actors. Cannot add more.");
                            Console.ReadKey();
                            return;
                        }

                        // Prompt and add actors if the movie has less than 4 actors
                        for (int i = 0; i < 4; i++)
                        {
                            Console.Write($"Actor {i + 1} Name: ");
                            FullName = Console.ReadLine().ToLower().Trim();

                            Console.Write($"Actor {i + 1} BirthYear: ");
                            BirthYear = Console.ReadLine().ToLower().Trim();

                            Console.Write($"Actor {i + 1} Rating (1-5): ");
                            Score = Console.ReadLine().ToLower().Trim();

                            Console.Write($"Actor {i + 1} Country: ");
                            Country = Console.ReadLine().ToLower().Trim();

                            // Append actor data to the existing string
                            ActorData += $"{FullName};{BirthYear};{Score};{Country};";
                        }

                        // Remove the trailing ";" from the ActorData
                        ActorData = ActorData.TrimEnd(';');

                        // Append actors' data to the existing line
                        lines[index] += $";{ActorData}";
                        File.WriteAllLines(FilePath, lines);
                        Console.WriteLine($"Actors of '{MovieTitle}' added successfully.");
                    }
                    else
                    {
                        Console.WriteLine($"Movie '{MovieTitle}' not found in the library.");
                    }
                }
                else
                {
                    Console.WriteLine($"Account: {_userRegistration.UserName} not found. Try Later..");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
