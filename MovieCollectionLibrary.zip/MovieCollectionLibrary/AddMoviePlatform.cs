﻿namespace MovieCollectionLibrary
{
    public interface IAddMoviePlatformFactory
    {
        AddMoviePlatform CreateMoviePlatform(IUserRegistration userRegistration);
    }

    public class AddMoviePlatformFactory : IAddMoviePlatformFactory
    {
        public AddMoviePlatform CreateMoviePlatform(IUserRegistration userRegistration)
        {
            return new AddMoviePlatform(userRegistration);
        }
    }

    public class AddMoviePlatform : IPlatform, IMoviePlatforms
    {
        public string PlatformName { get; set; }
        public string PlatformRate { get; set; }
        public string PlatformDescription { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string MovieTitle { get; set; }

        private readonly IUserRegistration _userRegistration;

        public AddMoviePlatform(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Platforms()
        {
            try
            {
                _userRegistration.Register();
                FileName = $"{_userRegistration.UserName}.txt";
                FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

                Console.Write("Enter Movie Title: ");
                MovieTitle = Console.ReadLine().ToLower().Trim();

                // Check if the movie already exists in the file
                if (File.Exists(FilePath))
                {
                    string[] lines = File.ReadAllLines(FilePath);

                    int index = Array.FindIndex(lines, line => line.StartsWith(MovieTitle + ";", StringComparison.OrdinalIgnoreCase));

                    if (index != -1)
                    {
                        // Check if the movie already has platform information
                        if (lines[index].Split(';').Length >= 22)
                        {
                            Console.WriteLine($"The movie '{MovieTitle.ToUpper()}' already has platform information. Cannot add more.");
                            Console.ReadKey();
                            return;
                        }

                        Console.Write("Enter Platform Name: ");
                        PlatformName = Console.ReadLine().ToLower().Trim();
                        Console.Write("Enter Platform Rate: ");
                        PlatformRate = Console.ReadLine().ToLower().Trim();
                        Console.Write("Enter Platform Description: ");
                        PlatformDescription = Console.ReadLine().ToLower().Trim();

                        // Append platform data to the existing string
                        lines[index] += $";{PlatformName};{PlatformRate};{PlatformDescription}";
                        File.WriteAllLines(FilePath, lines);
                        Console.WriteLine($"Platform '{PlatformName}' added successfully for the movie '{MovieTitle}'.");
                    }
                    else
                    {
                        Console.WriteLine($"Movie '{MovieTitle}' not found in the library.");
                    }
                }
                else
                {
                    Console.WriteLine($"Account: {_userRegistration.UserName} not found. Try Later..");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
