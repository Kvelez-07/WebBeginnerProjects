﻿namespace MovieCollectionLibrary
{
    public class CinemaLibraryMenu
    {
        public void CallMenu() // Main menu
        {
            bool exit = false;

            do
            {
                Console.Clear(); // Clean screen

                Console.WriteLine("Welcome to the Cinema Library App");
                Console.WriteLine("1. User Management");
                Console.WriteLine("2. Movie Data");
                Console.WriteLine("3. Actor Info");
                Console.WriteLine("4. Platform Info");
                Console.WriteLine("0. Exit");
                Console.Write("Choose an option to start: ");
                string mainOption = Console.ReadLine();

                switch (mainOption)
                {
                    case "1":
                        UserMenu();
                        break;
                    case "2":
                        MovieMenu();
                        break;
                    case "3":
                        ActorMenu();
                        break;
                    case "4":
                        PlatFormMenu();
                        break;
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Option not available.");
                        break;
                }

            } while (!exit);
        }

        private void UserMenu()
        {
            bool exit = false;

            do
            {
                Console.Clear();

                Console.WriteLine("User Menu");
                Console.WriteLine("1. Register User");
                Console.WriteLine("2. Remove User");
                Console.WriteLine("0. Back to Main Menu");
                Console.Write("Choose an option: ");
                string optionMenu = Console.ReadLine();

                IRegisterServiceFactory userRegisterServiceFactory = new RegisterServiceFactory(); // Factory instance
                IUserRegistration userRegistration = userRegisterServiceFactory.CreateUserRegistration();

                switch (optionMenu)
                {
                    case "1":
                        IFileSaver fileSaver = new RegisterServiceFactory().CreateFileSaver(userRegistration); // Injection
                        UserRegistrationService register = new RegisterServiceFactory().CreateUserRegistrationService(userRegistration, fileSaver);
                        register.RegisterUser();
                        break;
                    case "2":
                        UserRemoval userRemovalService = new UserRemoval();
                        userRemovalService.Remove();
                        break;
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Option not available.");
                        break;
                }

            } while (!exit);
        }

        private void MovieMenu() // By: Kevin Velez
        {
            bool exit = false;

            do
            {
                Console.Clear();

                Console.WriteLine("Movie Info Menu");
                Console.WriteLine("1. Add Movie");
                Console.WriteLine("2. Search (Title/Rating)");
                Console.WriteLine("3. Edit Film Details");
                Console.WriteLine("4. Show Movie Rankings");
                Console.WriteLine("0. Back to Main Menu");
                Console.Write("Choose an option: ");
                string optionMenu = Console.ReadLine();

                IRegisterServiceFactory userRegisterServiceFactory = new RegisterServiceFactory(); // Only one factory instance.
                IUserRegistration userRegistration = userRegisterServiceFactory.CreateUserRegistration();

                switch (optionMenu)
                {
                    case "1":
                        IMovieAddition movieAddition = new MovieAddition(userRegistration);
                        movieAddition.Add();
                        break;
                    case "2":
                        IMovieSearch movieSearch = new MovieSearchFactory().CreateMovieSearch(userRegistration);
                        movieSearch.Search();
                        break;
                    case "3":
                        IMovieEdition movieEdition = new MovieEditionFactory().CreateMovieEdition(userRegistration);
                        movieEdition.Edit();
                        break;
                    case "4":
                        IMovieList movieRankings = new MovieListFactory().CreateMovieList(userRegistration);
                        movieRankings.Listing();
                        break;
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Option not available.");
                        break;
                }

            } while (!exit);
        }

        private void ActorMenu() // By: Claudio Vargs
        {
            bool exit = false;

            do
            {
                Console.Clear();

                Console.WriteLine("Actor Info Menu");
                Console.WriteLine("1. Add Movie Actors");
                Console.WriteLine("2. Search Movie Actors");
                Console.WriteLine("3. Movie Actors Ranking");
                Console.WriteLine("4. List Best Actors");
                Console.WriteLine("0. Back to Main Menu");
                Console.Write("Choose an option: ");
                string optionMenu = Console.ReadLine();

                IRegisterServiceFactory userRegisterServiceFactory = new RegisterServiceFactory(); // Factory instance
                IUserRegistration userRegistration = userRegisterServiceFactory.CreateUserRegistration();

                switch (optionMenu)
                {
                    case "1":
                        IAddMovieActorsFactory addMovieActorsFactory = new AddMovieActorsFactory();
                        AddMovieActors addMovieActors = addMovieActorsFactory.CreateAddMovieActors(userRegistration);
                        addMovieActors.Actors();
                        break;
                    case "2":
                        ISearchMovieActorsFactory searchMovieActorsFactory = new SearchMovieActorsFactory();
                        SearchMovieActors searchMovieActors = searchMovieActorsFactory.CreateSearchMovieActors(userRegistration);
                        searchMovieActors.Actors();
                        break;
                    case "3":
                        IMovieActorsRankingFactory actorsRankingFactory = new MovieActorsRankingFactory();
                        MovieActorsRanking actorsRanking = actorsRankingFactory.CreateMovieActorsRanking(userRegistration);
                        actorsRanking.Actors();
                        break;
                    case "4":
                        IListBestActorsFactory bestActorsFactory = new ListBestActorsFactory();
                        ListBestActors bestActors = bestActorsFactory.CreateListBestActors(userRegistration);
                        bestActors.Actors();
                        break;
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Option not available.");
                        break;
                }

            } while (!exit);
        }

        private void PlatFormMenu() // By: Maicol Vargas
        {
            bool exit = false;

            do
            {
                Console.Clear();

                Console.WriteLine("Platform Info Menu");
                Console.WriteLine("1. Add Movie Platform");
                Console.WriteLine("2. Search Movie Platform");
                Console.WriteLine("3. Movie Platform Rankings");
                Console.WriteLine("4. List Best Platforms");
                Console.WriteLine("0. Back to Main Menu");
                Console.Write("Choose an option: ");
                string optionMenu = Console.ReadLine();

                IRegisterServiceFactory userRegisterServiceFactory = new RegisterServiceFactory(); // Factory instance.
                IUserRegistration userRegistration = userRegisterServiceFactory.CreateUserRegistration();

                switch (optionMenu)
                {
                    case "1":
                        IAddMoviePlatformFactory addMoviePlatformFactory = new AddMoviePlatformFactory();
                        AddMoviePlatform addMoviePlatform = addMoviePlatformFactory.CreateMoviePlatform(userRegistration);
                        addMoviePlatform.Platforms();
                        break;
                    case "2":
                        ISearchMoviePlatformFactory searchMoviePlatformFactory = new SearchMoviePlatformFactory();
                        SearchMoviePlatform searchMoviePlatform = searchMoviePlatformFactory.CreateSearchMoviePlatform(userRegistration);
                        searchMoviePlatform.Platforms();
                        break;
                    case "3":
                        IMoviePlatformRankingsFactory platformRankingsFactory = new MoviePlatformRankingFactory();
                        MoviePlatformRanking platformRankings = platformRankingsFactory.CreateMoviePlatformRanking(userRegistration);
                        platformRankings.Platforms();
                        break;
                    case "4":
                        IListBestPlatformsFactory bestPlatformsFactory = new ListBestPlatformsFactory();
                        ListBestPlatforms bestPlatforms = bestPlatformsFactory.CreateListBestPlatforms(userRegistration);
                        bestPlatforms.Platforms();
                        break;
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Option not available.");
                        break;
                }

            } while (!exit);
        }
    }
}
