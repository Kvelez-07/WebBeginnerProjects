﻿namespace MovieCollectionLibrary
{
    public interface IUserRegistration // Account SingUp and LogIn
    {
        string UserName { get; set; }
        void Register();
    }

    public interface IUserRemoval // Deletion
    {
        string UserName { get; set; }
        void Remove();
    }
    public interface IFileManagement // Debug Directory
    {
        string FilePath { get; set; }
        string FileName { get; set; }
    }

    public interface IFileSaver : IFileManagement
    {
        void Save();
    }

    public interface IFileReader : IFileManagement // For future updates
    {
        void Read();
    }

    public interface IFileDeleter : IFileManagement // For future updates.
    {
        void Delete();
    }
}
