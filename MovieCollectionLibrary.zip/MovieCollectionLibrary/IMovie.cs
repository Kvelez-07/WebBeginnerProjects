﻿namespace MovieCollectionLibrary
{
    public interface IMovie
    {
        string Title { get; set; }
        string Rating { get; set; }
        string ReleaseDate { get; set; }
        string Status { get; set; }
        string MovieData { get; set; }
    }

    public interface IMovieAddition : IMovie, IFileManagement // Add movies
    {
        void Add();
    }

    public interface IMovieDeletion : IMovie, IFileManagement // Remove movies
    {
        void Delete();
    }

    public interface IMovieSearch : IMovie, IFileManagement // Fetch movies
    {
        void Search();
    }
    public interface IMovieEdition : IMovie, IFileManagement // Edit movies
    {
        void Edit();
    }
    public interface IMovieList : IMovie, IFileManagement // List movies
    {
        void Listing();
    }
    public interface IMovieActors : IFileManagement // Actor management
    {
        void Actors();
    }
    public interface IMoviePlatforms : IFileManagement // Platform management
    {
        void Platforms();
    }
}
