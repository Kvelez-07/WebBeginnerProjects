﻿namespace MovieCollectionLibrary
{
    public interface IPerson // Actors or Users
    {
        string FullName { get; set; }
        string BirthYear { get; set; }
        string Score { get; set; } // rating
        string Country { get; set; }
        string MovieTitle { get; set; }
        string ActorData { get; set; }
    }
}
