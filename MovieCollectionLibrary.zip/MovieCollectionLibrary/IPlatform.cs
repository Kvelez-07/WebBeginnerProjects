﻿namespace MovieCollectionLibrary
{
    public interface IPlatform
    {
        string PlatformName { get; set; }
        string PlatformRate { get; set; }
        string PlatformDescription { get; set; }
        string MovieTitle { get; set; }
    }
}
