﻿namespace MovieCollectionLibrary
{
    public interface IListBestActorsFactory
    {
        ListBestActors CreateListBestActors(IUserRegistration userRegistration);
    }

    public class ListBestActorsFactory : IListBestActorsFactory
    {
        public ListBestActors CreateListBestActors(IUserRegistration userRegistration)
        {
            return new ListBestActors(userRegistration);
        }
    }

    public class ListBestActors : IPerson, IMovieActors
    {
        public string FullName { get; set; }
        public string BirthYear { get; set; }
        public string Score { get; set; }
        public string Country { get; set; }
        public string MovieTitle { get; set; }
        public string ActorData { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration; // Injection

        public ListBestActors(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Actors()
        {
            _userRegistration.Register();
            FileName = $"{_userRegistration.UserName}.txt";
            FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

            if (!File.Exists(FilePath))
            {
                Console.WriteLine($"Account {_userRegistration.UserName} not found. Try later.");
                Console.ReadKey();
                return; // Terminate process.
            }

            Console.Write("\nMovie Title: ");
            MovieTitle = Console.ReadLine().ToLower().Trim();

            string content = File.ReadAllText(FilePath);
            string[] entries = content.Split('\n'); // Line break per movie

            var movieDetails = (from entry in entries // LINQ
                                where !string.IsNullOrWhiteSpace(entry)
                                let details = entry.Split(';')
                                where details.Length >= 4 && MovieTitle == details[0].ToLower().Trim()
                                select details).FirstOrDefault();

            if (movieDetails != null)
            {
                int numberOfActors = (movieDetails.Length - 4) / 4; // Skip movie data

                if (numberOfActors == 0)
                {
                    Console.WriteLine($"No actors added for the movie '{MovieTitle}'.");
                }
                else
                {
                    var actors = (from j in Enumerable.Range(0, numberOfActors)
                                  select new
                                  {
                                      ActorStartIndex = 4 + j * 4,
                                      Actor = movieDetails[4 + j * 4],
                                      BirthYear = movieDetails[5 + j * 4],
                                      Score = movieDetails[6 + j * 4],
                                      Country = movieDetails[7 + j * 4]
                                  })
                      .Where(actor => actor.Score == "5")
                      .OrderByDescending(actor => actor.Score)
                      .Take(3); // Top 3

                    actors.ToList().ForEach(actor =>
                    {
                        Console.WriteLine($"\nActor: {actor.Actor}");
                        Console.WriteLine($"Birth Year: {actor.BirthYear}");
                        Console.WriteLine($"Score: {actor.Score}");
                        Console.WriteLine($"Country: {actor.Country}");
                    }); 
                }
            }
            else
            {
                Console.WriteLine($"Movie '{MovieTitle}' not found.");
            }

            Console.ReadKey();
        }
    }
}
