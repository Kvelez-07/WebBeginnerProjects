﻿namespace MovieCollectionLibrary
{
    public interface IListBestPlatformsFactory
    {
        ListBestPlatforms CreateListBestPlatforms(IUserRegistration userRegistration);
    }

    public class ListBestPlatformsFactory : IListBestPlatformsFactory
    {
        public ListBestPlatforms CreateListBestPlatforms(IUserRegistration userRegistration)
        {
            return new ListBestPlatforms(userRegistration);
        }
    }

    public class ListBestPlatforms : IPlatform, IMoviePlatforms
    {
        private readonly IUserRegistration _userRegistration;

        public ListBestPlatforms(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public string PlatformName { get; set; }
        public string PlatformRate { get; set; }
        public string PlatformDescription { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string MovieTitle { get; set; }

        public void Platforms()
        {
            try
            {
                _userRegistration.Register();

                FileName = $"{_userRegistration.UserName}.txt";
                FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

                if (File.Exists(FilePath))
                {
                    string[] lines = File.ReadAllLines(FilePath);

                    var topPlatforms = lines
                        .Skip(1) // Skip header
                        .Select(line =>
                        {
                            var values = line.Split(';');
                            return new
                            {
                                PlatformName = values.Length > 20 ? values[20] : "Unknown", // null or empty
                                PlatformRate = values.Length > 21 ? values[21] : "Unknown"
                            };
                        })
                        .Where(platform => platform.PlatformRate == "5") // rating
                        .GroupBy(platform => platform.PlatformName)
                        .OrderByDescending(group => group.Count())
                        .Take(3) // top 3
                        .Select(group => group.Key);

                    Console.WriteLine("\nTop 3 Best Platforms:");
                    foreach (var platform in topPlatforms)
                    {
                        Console.WriteLine(platform);
                    }
                }
                else
                {
                    Console.WriteLine($"Account: {_userRegistration.UserName} not found. Try Later..");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
