﻿namespace MovieCollectionLibrary
{
    public interface IMovieActorsRankingFactory
    {
        MovieActorsRanking CreateMovieActorsRanking(IUserRegistration userRegistration);
    }

    public class MovieActorsRankingFactory : IMovieActorsRankingFactory
    {
        public MovieActorsRanking CreateMovieActorsRanking(IUserRegistration userRegistration)
        {
            return new MovieActorsRanking(userRegistration);
        }
    }

    public class MovieActorsRanking : IPerson, IMovieActors
    {
        public string FullName { get; set; }
        public string BirthYear { get; set; }
        public string Score { get; set; }
        public string Country { get; set; }
        public string MovieTitle { get; set; }
        public string ActorData { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration; // Injection

        public MovieActorsRanking(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Actors()
        {
            _userRegistration.Register();
            FileName = $"{_userRegistration.UserName}.txt";
            FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

            if (!File.Exists(FilePath))
            {
                Console.WriteLine($"Account {_userRegistration.UserName} not found. Try later.");
                Console.ReadKey();
                return;
            }

            Console.Write("\nMovie Title: ");
            MovieTitle = Console.ReadLine().ToLower().Trim();

            string content = File.ReadAllText(FilePath);
            string[] entries = content.Split('\n');

            var movieDetails = (from entry in entries
                                where !string.IsNullOrWhiteSpace(entry)
                                let details = entry.Split(';')
                                where details.Length >= 4 && MovieTitle == details[0].ToLower().Trim()
                                select details).FirstOrDefault();

            if (movieDetails != null)
            {
                int numberOfActors = (movieDetails.Length - 4) / 4;

                if (numberOfActors == 0)
                {
                    Console.WriteLine($"No actors added for the movie '{MovieTitle}'.");
                }
                else
                {
                    var actors = (from j in Enumerable.Range(0, numberOfActors)
                                  select new
                                  {
                                      ActorStartIndex = 4 + j * 4,
                                      Actor = movieDetails[4 + j * 4],
                                      BirthYear = movieDetails[5 + j * 4],
                                      Score = movieDetails[6 + j * 4],
                                      Country = movieDetails[7 + j * 4]
                                  });

                    actors.ToList().ForEach(actor =>
                    {
                        Console.WriteLine($"\nActor: {actor.Actor}");
                        Console.WriteLine($"Birth Year: {actor.BirthYear}");
                        Console.WriteLine($"Score: {actor.Score}");
                        Console.WriteLine($"Country: {actor.Country}");
                    }); 
                }
            }
            else
            {
                Console.WriteLine($"Movie '{MovieTitle}' not found.");
            }
            Console.ReadKey();
        }
    }
}
