﻿using MovieCollectionLibrary;

public class MovieAddition : IMovieAddition
{
    public string Title { get; set; }
    public string Rating { get; set; }
    public string ReleaseDate { get; set; }
    public string Status { get; set; }
    public string FilePath { get; set; }
    public string FileName { get; set; }
    public string MovieData { get; set; }

    private readonly IUserRegistration _userRegistration;

    public MovieAddition(IUserRegistration userRegistration)
    {
        _userRegistration = userRegistration;
    }

    public void Add()
    {
        try
        {
            _userRegistration.Register();
            FileName = $"{_userRegistration.UserName}.txt";
            FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

            if (File.Exists(FilePath))
            {
                Console.WriteLine("\nEnter Movie Details");
                Console.Write("Title: ");
                Title = Console.ReadLine().ToLower().Trim();

                // Check if the movie title already exists in the file
                bool movieExists = File.ReadLines(FilePath)
                    .Any(line => line.ToLower().StartsWith(Title + ";"));

                if (movieExists)
                {
                    Console.WriteLine($"Movie with title '{Title}' already exists. Cannot add duplicate.");
                    Console.ReadKey();
                    return;
                }

                Console.Write("Rating (1-5): ");
                Rating = Console.ReadLine().ToLower().Trim();
                Console.Write("Release Year: ");
                ReleaseDate = Console.ReadLine().ToLower().Trim();
                Console.Write("Status (loved/seen/to see): ");
                Status = Console.ReadLine().ToLower().Trim();
            }

            // If the movie doesn't exist, add it to the file
            MovieData = $"{Title};{Rating};{ReleaseDate};{Status}";
            if (!File.Exists(FilePath))
            {
                File.WriteAllText(FilePath, MovieData); // override
            }
            else
            {
                File.AppendAllText(FilePath, Environment.NewLine + $"{MovieData}"); // append with line break
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
