﻿namespace MovieCollectionLibrary
{
    public interface IMovieEditionFactory
    {
        IMovieEdition CreateMovieEdition(IUserRegistration userRegistration);
    }

    public class MovieEditionFactory : IMovieEditionFactory
    {
        public IMovieEdition CreateMovieEdition(IUserRegistration userRegistration)
        {
            return new MovieEdition(userRegistration);
        }
    }

    public class MovieEdition : IMovieEdition
    {
        public string Title { get; set; }
        public string Rating { get; set; }
        public string ReleaseDate { get; set; }
        public string Status { get; set; }
        public string MovieData { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration; // Injection

        public MovieEdition(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Edit()
        {
            Console.WriteLine("Edit Movie Details");
            Console.Write("Title: ");
            Title = Console.ReadLine().ToLower().Trim();

            _userRegistration.Register();
            FileName = $"{_userRegistration.UserName}.txt";
            FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

            try
            {
                if (File.Exists(FilePath))
                {
                    // Read all lines from the file
                    string[] lines = File.ReadAllLines(FilePath);

                    int index = Array.FindIndex(lines, line => line.StartsWith(Title + ";", StringComparison.OrdinalIgnoreCase));

                    if (index != -1)
                    {
                        string[] movieDetails = lines[index].Split(';');

                        Console.Write($"Current Rating ({movieDetails[1]}): ");
                        Rating = Console.ReadLine().Trim();
                        Console.Write($"Current Release Year ({movieDetails[2]}): ");
                        ReleaseDate = Console.ReadLine().Trim();
                        Console.Write($"Current Status ({movieDetails[3]}): ");
                        Status = Console.ReadLine().Trim();

                        // Preserve existing actors' data
                        string actorsData = string.Join(";", movieDetails.Skip(4));

                        MovieData = $"{Title};{Rating};{ReleaseDate};{Status};{actorsData}";

                        lines[index] = MovieData;
                        File.WriteAllLines(FilePath, lines);
                        Console.WriteLine($"Movie '{Title}' updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine($"Movie '{Title}' not found in the library.");
                    }
                }
                else
                {
                    Console.WriteLine($"Account: {FileName} not found. Try Later..");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
