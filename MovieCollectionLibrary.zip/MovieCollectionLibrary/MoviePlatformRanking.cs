﻿namespace MovieCollectionLibrary
{
    public interface IMoviePlatformRankingsFactory
    {
        MoviePlatformRanking CreateMoviePlatformRanking(IUserRegistration userRegistration);
    }

    public class MoviePlatformRankingFactory : IMoviePlatformRankingsFactory
    {
        public MoviePlatformRanking CreateMoviePlatformRanking(IUserRegistration userRegistration)
        {
            return new MoviePlatformRanking(userRegistration);
        }
    }

    public class MoviePlatformRanking : IPlatform, IMoviePlatforms
    {
        public string PlatformName { get; set; }
        public string PlatformRate { get; set; }
        public string PlatformDescription { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string MovieTitle { get; set; }

        private readonly IUserRegistration _userRegistration;

        public MoviePlatformRanking(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Platforms()
        {
            try
            {
                _userRegistration.Register(); // logIn

                FileName = $"{_userRegistration.UserName}.txt";
                FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

                if (File.Exists(FilePath))
                {
                    string[] lines = File.ReadAllLines(FilePath);

                    var platformRankings = lines
                        .Skip(1) // skip file init
                        .Select(line =>
                        {
                            var values = line.Split(';');
                            return new
                            {
                                Rating = values.Length > 21 ? values[21] : "Unknown"
                            };
                        })
                        .GroupBy(platform => platform.Rating)
                        .ToDictionary(
                            grouping => grouping.Key,
                            grouping => grouping.Count()
                        );

                    Console.WriteLine("\nMovie platform ratings:");
                    foreach (var kvp in platformRankings)
                    {
                        Console.WriteLine($"Ranking {kvp.Key}: {kvp.Value} platform(s).");
                    }
                }
                else
                {
                    Console.WriteLine($"Account: {_userRegistration.UserName} not found. Try Later..");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
