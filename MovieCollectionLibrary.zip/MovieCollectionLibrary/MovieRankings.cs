﻿namespace MovieCollectionLibrary
{
    public interface IMovieListFactory
    {
        IMovieList CreateMovieList(IUserRegistration userRegistration);
    }

    public class MovieListFactory : IMovieListFactory
    {
        public IMovieList CreateMovieList(IUserRegistration userRegistration)
        {
            return new MovieRankings(userRegistration);
        }
    }
    public class MovieRankings : IMovieList
    {
        public string Title { get; set; }
        public string Rating { get; set; }
        public string ReleaseDate { get; set; }
        public string Status { get; set; }
        public string MovieData { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration; // Injection

        public MovieRankings(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Listing()
        {
            _userRegistration.Register();
            FileName = $"{_userRegistration.UserName}.txt";
            FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

            if (File.Exists(FilePath))
            {
                string content = File.ReadAllText(FilePath);
                string[] entries = content.Split('\n');

                var ratingCounts = (from entry in entries // LINQ
                                    where !string.IsNullOrWhiteSpace(entry)
                                    let movieDetails = entry.Split(';')
                                    where movieDetails.Length >= 2
                                    let rating = int.TryParse(movieDetails[1], out int r) ? r : 0
                                    group rating by rating <= 2 ? "1-2" : (rating == 3 ? "3" : "4-5") into g
                                    select new { Range = g.Key, Count = g.Count() })
                   .ToDictionary(result => result.Range, result => result.Count); // Dictionary

                ratingCounts.ToList().ForEach(kvp => Console.WriteLine($"Movies ranked: {kvp.Key} : {kvp.Value}")); // Dictionary with ratings

                var allMovies = from entry in entries // LINQ
                                where !string.IsNullOrWhiteSpace(entry)
                                let movieDetails = entry.Split(';')
                                where movieDetails.Length >= 4
                                select new
                                {
                                    Title = movieDetails[0],
                                    Rating = movieDetails[1],
                                    ReleaseDate = movieDetails[2],
                                    Status = movieDetails[3]
                                };

                allMovies.ToList().ForEach(movie => // Lambda
                {
                    Console.WriteLine($"\nMovie: {movie.Title}");
                    Console.WriteLine($"Rating: {movie.Rating}");
                    Console.WriteLine($"Release: {movie.ReleaseDate}");
                    Console.WriteLine($"Status: {movie.Status}");
                });
            }
            else
            {
                Console.WriteLine($"Account {_userRegistration.UserName} not found. Try later.");
            }
            Console.ReadKey();
        }
    }
}
