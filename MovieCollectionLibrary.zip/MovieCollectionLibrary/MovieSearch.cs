﻿namespace MovieCollectionLibrary
{
    public interface IMovieSearchFactory
    {
        IMovieSearch CreateMovieSearch(IUserRegistration userRegistration);
    }

    public class MovieSearchFactory : IMovieSearchFactory
    {
        public IMovieSearch CreateMovieSearch(IUserRegistration userRegistration)
        {
            return new MovieSearch(userRegistration);
        }
    }
    public class MovieSearch : IMovieSearch
    {
        public string Title { get; set; }
        public string Rating { get; set; }
        public string ReleaseDate { get; set; }
        public string Status { get; set; }
        public string MovieData { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration; // Injection

        public MovieSearch(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Search()
        {
            try
            {
                Console.WriteLine("Search Movie Details");
                Console.Write("Title: ");
                Title = Console.ReadLine().ToLower().Trim();
                Console.Write("Rating (1-5): ");
                Rating = Console.ReadLine().ToLower().Trim();

                _userRegistration.Register();
                FileName = $"{_userRegistration.UserName}.txt";
                FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

                if (File.Exists(FilePath))
                {
                    string content = File.ReadAllText(FilePath); // File Parsing
                    string[] entries = content.Split('\n');

                    var queryFile = from entry in entries // LINQ
                                    where entry.Split(';').Length >= 4
                                          && Title.Equals(entry.Split(';')[0])
                                          && Rating.Equals(entry.Split(';')[1])
                                    select entry;

                    queryFile.ToList().ForEach(query => // Lambda
                    {
                        Console.WriteLine($"\nMovie: {query.Split(';')[0]}");
                        Console.WriteLine($"Rating: {query.Split(';')[1]}");
                        Console.WriteLine($"Release: {query.Split(';')[2]}");
                        Console.WriteLine($"Status: {query.Split(';')[3]}");
                    });
                }
                else
                {
                    Console.WriteLine($"Account {_userRegistration.UserName} not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
