﻿using MovieCollectionLibrary;

var cinema = new CinemaLibraryMenu();
cinema.CallMenu();