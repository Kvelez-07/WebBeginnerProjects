﻿namespace MovieCollectionLibrary
{
    public interface ISearchMovieActorsFactory
    {
        SearchMovieActors CreateSearchMovieActors(IUserRegistration userRegistration);
    }

    public class SearchMovieActorsFactory : ISearchMovieActorsFactory
    {
        public SearchMovieActors CreateSearchMovieActors(IUserRegistration userRegistration)
        {
            return new SearchMovieActors(userRegistration);
        }
    }

    public class SearchMovieActors : IPerson, IMovieActors
    {
        public string FullName { get; set; }
        public string BirthYear { get; set; }
        public string Score { get; set; }
        public string Country { get; set; }
        public string MovieTitle { get; set; }
        public string ActorData { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration; // Injection

        public SearchMovieActors(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Actors()
        {
            try
            {
                _userRegistration.Register();
                FileName = $"{_userRegistration.UserName}.txt";
                FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

                Console.WriteLine("\nProvide Actor Details");

                Console.Write("Movie Title: ");
                MovieTitle = Console.ReadLine().ToLower().Trim();

                Console.Write("Actor FullName: ");
                FullName = Console.ReadLine().ToLower().Trim();

                Console.Write("Actor BirthYear: ");
                BirthYear = Console.ReadLine().ToLower().Trim();

                Console.Write("Actor Rating (1-5): ");
                Score = Console.ReadLine().ToLower().Trim();

                Console.Write("Actor Country: ");
                Country = Console.ReadLine().ToLower().Trim();

                ActorData = $"{FullName};{BirthYear};{Score};{Country}";

                if (File.Exists(FilePath))
                {
                    string[] lines = File.ReadAllLines(FilePath);

                    var queryFile = from line in lines // LINQ
                                    where line.Contains($"{MovieTitle}")
                                    where line.Contains($"{ActorData}")
                                    select line;

                    if (queryFile.Any())
                    {
                        Console.WriteLine($"'{MovieTitle.ToUpper()}' => Actor '{FullName}' with rating '{Score}' found!");
                    }
                    else
                    {
                        Console.WriteLine($"Actor '{FullName}' with rating '{Score}' not found in the movie '{MovieTitle}'.");
                    }
                }
                else
                {
                    Console.WriteLine($"Account {_userRegistration.UserName} not in system.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.ReadKey();
            }
        }
    }
}
