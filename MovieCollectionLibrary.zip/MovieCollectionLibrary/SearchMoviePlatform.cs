﻿namespace MovieCollectionLibrary
{
    public interface ISearchMoviePlatformFactory
    {
        SearchMoviePlatform CreateSearchMoviePlatform(IUserRegistration userRegistration);
    }

    public class SearchMoviePlatformFactory : ISearchMoviePlatformFactory
    {
        public SearchMoviePlatform CreateSearchMoviePlatform(IUserRegistration userRegistration)
        {
            return new SearchMoviePlatform(userRegistration);
        }
    }

    public class SearchMoviePlatform : IPlatform, IMoviePlatforms
    {
        public string PlatformName { get; set; }
        public string PlatformRate { get; set; }
        public string PlatformDescription { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string MovieTitle { get; set; }

        private readonly IUserRegistration _userRegistration;

        public SearchMoviePlatform(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Platforms()
        {
            try
            {
                _userRegistration.Register();

                Console.Write("Enter Movie Title: ");
                MovieTitle = Console.ReadLine().ToLower().Trim();
                Console.Write("Enter Platform Name: ");
                PlatformName = Console.ReadLine().ToLower().Trim();

                FileName = $"{_userRegistration.UserName}.txt";
                FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

                // Check if the movie file exists
                if (File.Exists(FilePath))
                {
                    string[] lines = File.ReadAllLines(FilePath);

                    // Use LINQ to find the movie line that contains the specified platform
                    var movieLine = lines.FirstOrDefault(line =>
                    {
                        var values = line.Split(';');
                        return values.Length >= 22 &&
                               values[0].ToLower().Trim() == MovieTitle &&
                               values[20].ToLower().Trim().StartsWith(PlatformName);
                    });

                    if (movieLine != null)
                    {
                        var movieValues = movieLine.Split(';');

                        Console.WriteLine($"\nPlatform: {movieValues[20]}");
                        Console.WriteLine($"Rating: {movieValues[21]}");
                        Console.WriteLine($"Description: {movieValues[22]}");
                        Console.WriteLine($"Found in: {MovieTitle}");
                    }
                    else
                    {
                        Console.WriteLine($"No platform found with specified details in the movie '{MovieTitle.ToUpper()}'.");
                    }
                }
                else
                {
                    Console.WriteLine($"Account: {_userRegistration.UserName} not found. Try Later..");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
