﻿namespace MovieCollectionLibrary
{
    public interface IRegisterServiceFactory
    {
        IUserRegistration CreateUserRegistration();
        IFileSaver CreateFileSaver(IUserRegistration userRegistration);
        UserRegistrationService CreateUserRegistrationService(IUserRegistration userRegistration, IFileSaver fileSaver);
    }

    public class RegisterServiceFactory : IRegisterServiceFactory
    {
        public IUserRegistration CreateUserRegistration()
        {
            return new UserRegistration();
        }

        public IFileSaver CreateFileSaver(IUserRegistration userRegistration)
        {
            return new FileSaver(userRegistration);
        }

        public UserRegistrationService CreateUserRegistrationService(IUserRegistration userRegistration, IFileSaver fileSaver)
        {
            return new UserRegistrationService(userRegistration, fileSaver);
        }
    }
    public class UserRegistration : IUserRegistration
    {
        public string UserName { get; set; }

        public void Register()
        {
            Console.Write("UserName: ");
            UserName = Console.ReadLine();
        }
    }
    public class FileSaver : IFileSaver
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }

        private readonly IUserRegistration _userRegistration; // Injection

        public FileSaver(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        public void Save()
        {
            _userRegistration.Register(); // Abstract.
            FileName = $"{_userRegistration.UserName}.txt";
            FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

            if (File.Exists(FilePath))
            {
                Console.WriteLine($"User '{_userRegistration.UserName}' already exists. File not saved.");
                return;
            }

            File.WriteAllText(FilePath, "file init"); // init content to make file appear.
        }
    }
    public class UserRegistrationService
    {
        private readonly IUserRegistration _userRegistration;
        private readonly IFileSaver _fileSaver;

        public UserRegistrationService(IUserRegistration userRegistration, IFileSaver fileSaver)
        {
            _userRegistration = userRegistration;
            _fileSaver = fileSaver;
        }

        public void RegisterUser()
        {
            // Perform user registration and file saving
            _fileSaver.Save();
            Console.WriteLine($"File saved at: {_fileSaver.FilePath}");
            Console.WriteLine($"File name: {_fileSaver.FileName}");
            Console.WriteLine("Registration and file saving completed.");
            Console.ReadKey();
        }
    }
}
