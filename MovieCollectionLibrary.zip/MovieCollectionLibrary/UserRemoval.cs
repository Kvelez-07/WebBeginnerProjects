﻿namespace MovieCollectionLibrary
{
    public class UserRemoval : IFileManagement, IUserRemoval
    {
        public string UserName { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }

        public void Remove()
        {
            Console.Write("UserName: ");
            UserName = Console.ReadLine().ToLower().Trim();
            FileName = $"{UserName}.txt";
            FilePath = Path.Combine(Environment.CurrentDirectory, FileName);

            if (File.Exists(FilePath))
            {
                File.Delete(FilePath);
                Console.WriteLine($"Account {UserName} deleted successfully.");
            }
            else
            {
                Console.WriteLine($"Account {UserName} not in system.");
            }
            Console.ReadKey();
        }
    }
}
