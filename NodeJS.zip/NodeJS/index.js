import { getPostById, getPostLength, getPosts, getPostsLength } from './postController.js';
import { celsiusToFahrenheit, generateRandomNumber } from './utils.js';

console.log('Hello World');
console.log(`Random number: ${generateRandomNumber(0, 10)}`);
console.log(`Celsius to Fahrenheit: ${celsiusToFahrenheit(11)}`);

console.log(`Posts: ${JSON.stringify(getPosts())}`);
console.log(`Post: ${JSON.stringify(getPostById(0))}`);
console.log(`Posts length: ${getPostsLength()}`);
console.log(`Post length: ${getPostLength(2)}`);