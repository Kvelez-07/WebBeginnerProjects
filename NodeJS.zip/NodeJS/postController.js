const posts = [
    {
        id: 1,
        title: 'Post One',
        body: 'This is post one'
    },
    {
        id: 2,
        title: 'Post Two',
        body: 'This is post two'
    },
    {
        id: 3,
        title: 'Post Three',
        body: 'This is post three'
    }
]

export const getPosts = () => posts;
export const getPostById = (id) => posts.find(post => post.id === id);
export const getPostsLength = () => posts.length;
export const getPostLength = (id) => posts.filter(post => post.id === id).length;