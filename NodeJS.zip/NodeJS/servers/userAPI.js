import {createServer} from 'http';
const PORT = process.env.PORT || 3000;

const users = [
    {id: 1, name: 'John Doe'},
    {id: 2, name: 'Jane Doe'},
    {id: 3, name: 'Jim Doe'},
];

const server = createServer((req, res) => {
    if (req.method === 'GET') {
        handleGetRequest(req, res);
    } else {
        res.statusCode = 404;
        res.end();
    }
});

server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
});

async function handleGetRequest(req, res) {
    if (req.url === '/users') {
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(users));
    } else {
        res.statusCode = 404;
        res.end();
    }
}