export const generateRandomNumber = (min, max) => {
    return Math.floor(Math.random() * (max - min) + min);
};

export const celsiusToFahrenheit = (celsius) => {
    return (celsius * 9 / 5) + 32;
};