// Settings
const passwordLength = 12;
const includeLowercase = true;
const includeUppercase = true;
const includeNumbers = true;
const includeSymbols = true;

// Functions
function generatePassword(length, includeLowercase, includeUppercase, includeNumbers, includeSymbols) {

    const lowerCaseChars = 'abcdefghijklmnopqrstuvwxyz';
    const upperCaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numberChars = '0123456789';
    const symbolChars = '!@#$%^&*()_+~`|}{[]\:;?><,./-=';

    let allowedChars = ''; // initialize list of allowed characters
    let password = ''; // initialize password

    // build list of allowed characters
    allowedChars += includeLowercase ? lowerCaseChars : '';
    allowedChars += includeUppercase ? upperCaseChars : '';
    allowedChars += includeNumbers ? numberChars : '';
    allowedChars += includeSymbols ? symbolChars : '';

    if (length <= 0) { // check if length is valid
        return 'password length should be at least 1';
    }
    if (allowedChars.length === 0) { // check if at least one set of characters is selected
        return 'Select at least one set of characters';
    }

    for (let i = 0; i < length; i++) { // generate password
        const randomIndex = Math.floor(Math.random() * allowedChars.length);
        password += allowedChars[randomIndex]; // add char to password
    }

    return password; // return generated password
}

const password = generatePassword(passwordLength, includeLowercase, includeUppercase, includeNumbers, includeSymbols);
console.log(`Generated password: ${password}`);