// Constants
const boardWidth = 500;
const boardHeight = 500;
const playerWidth = 10;
const playerHeight = 50;
const ballWidth = 10;
const ballHeight = 10;
const playerVelocity = 2;

// Board
let board;
let context;

// Players
let player1;
let player2;

// Ball
let ball;

// Scores
let player1Score = 0;
let player2Score = 0;

window.onload = function() {
    initializeGame();
    requestAnimationFrame(update);
    document.addEventListener("keydown", playerMotion);
    document.addEventListener("keyup", stopPlayers);
};

function initializeGame() {
    // Initialize canvas and context
    board = document.getElementById("board");
    board.height = boardHeight;
    board.width = boardWidth;
    context = board.getContext("2d");

    // Initialize players
    player1 = createPlayer(10, boardHeight / 2, "dodgerBlue");
    player2 = createPlayer(boardWidth - playerWidth - 10, boardHeight / 2, "red");

    // Initialize ball
    ball = createBall(boardWidth / 2, boardHeight / 2, "white", 1, 2);
}

function createPlayer(x, y, color) {
    return {
        x: x,
        y: y,
        width: playerWidth,
        height: playerHeight,
        velocityY: 0,
        color: color
    };
}

function createBall(x, y, color, velocityX, velocityY) {
    return {
        x: x,
        y: y,
        width: ballWidth,
        height: ballHeight,
        velocityX: velocityX,
        velocityY: velocityY,
        color: color
    };
}

function update() {
    requestAnimationFrame(update);
    clearBoard();

    movePlayer(player1);
    movePlayer(player2);

    moveBall();

    drawPlayer(player1);
    drawPlayer(player2);

    drawBall();

    handleCollisions();

    updateScores();

    drawDivisionLine();

    drawScores();
}

function clearBoard() {
    context.clearRect(0, 0, board.width, board.height);
}

function movePlayer(player) {
    player.y += player.velocityY;
    player.y = Math.max(0, Math.min(boardHeight - player.height, player.y));
}

function drawPlayer(player) {
    context.fillStyle = player.color;
    context.fillRect(player.x, player.y, player.width, player.height);
}

function moveBall() {
    ball.x += ball.velocityX;
    ball.y += ball.velocityY;

    // Ball collision detection on the top and bottom
    if (ball.y <= 0 || ball.y + ball.height >= boardHeight) {
        ball.velocityY *= -1; // Change direction
    }
}

function drawBall() {
    context.fillStyle = ball.color;
    context.fillRect(ball.x, ball.y, ball.width, ball.height);
}

function handleCollisions() {
    if (detectCollision(ball, player1) || detectCollision(ball, player2)) {
        ball.velocityX *= -1;
    }

    // Game over conditions
    if (ball.x < 0) {
        player2Score++;
        reloadGame(1);
    } else if (ball.x > boardWidth) {
        player1Score++;
        reloadGame(-1);
    }
}

function updateScores() {
    context.font = "20px Arial";
    context.fillStyle = "white";
    context.fillText(player1Score, boardWidth / 4, boardHeight / 2);
    context.fillText(player2Score, (boardWidth / 4) * 3, boardHeight / 2);
}

function drawDivisionLine() {
    for (let i = 10; i < boardHeight; i += 25) {
        context.fillRect(boardWidth / 2 - 10, i, 5, 10);
    }
}

function drawScores() {
    context.font = "20px Arial";
    context.fillStyle = "white";
    context.fillText(player1Score, boardWidth / 4, boardHeight / 2);
    context.fillText(player2Score, (boardWidth / 4) * 3, boardHeight / 2);
}

function playerMotion(event) {
    // Player 1 moves
    if (event.code == 'KeyW') {
        player1.velocityY = -playerVelocity;
    } else if (event.code == 'KeyS') {
        player1.velocityY = playerVelocity;
    }

    // Player 2 moves
    if (event.code == 'ArrowUp') {
        player2.velocityY = -playerVelocity;
    } else if (event.code == 'ArrowDown') {
        player2.velocityY = playerVelocity;
    }
}

function stopPlayers(event) {
    // Stop player1
    if (event.code == 'KeyW' || event.code == 'KeyS') {
        player1.velocityY = 0;
    }

    // Stop player2
    if (event.code == 'ArrowUp' || event.code == 'ArrowDown') {
        player2.velocityY = 0;
    }
}

function detectCollision(a, b) {
    // Collision detection between two rectangles a and b
    return !(a.x > b.x + b.width || a.x + a.width < b.x || a.y > b.y + b.height || a.y + a.height < b.y);
}

function reloadGame(orientation) {
    ball = createBall(boardWidth / 2, boardHeight / 2, "white", orientation, 2);
}
