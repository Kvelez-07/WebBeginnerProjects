const choices = ['rock', 'paper', 'scissors']; // Array of possible choices
const playerDisplay = document.getElementById('playerDisplay');
const computerDisplay = document.getElementById('computerDisplay');
const resultDisplay = document.getElementById('resultDisplay');
const playerScoreDisplay = document.getElementById('playerScoreDisplay');
const computerScoreDisplay = document.getElementById('computerScoreDisplay');

let playerScore = 0; // Initialize player score
let computerScore = 0; // Initialize computer score

function playGame(playerChoice){
    let result = ''; // Initialize result
    const computerChoice = choices[Math.floor(Math.random() * 3)]; // Generate computer choice

    if (playerChoice === computerChoice){
        result = "It's a tie!";
    } else {
        switch(playerChoice){ // Determine the winner
            case 'rock':
                (computerChoice === 'paper') ? result = 'Computer Wins' : result = 'Player Wins';
                break;
            case 'paper':
                (computerChoice === 'scissors') ? result = 'Computer Wins' : result = 'Player Wins';
                break;
            case 'scissors':
                (computerChoice === 'rock') ? result = 'Computer Wins' : result = 'Player Wins';
                break;
            default:
                result = 'Error'; // Display error message
                break;
        }
    }

    // Display setup
    playerDisplay.textContent = `PLAYER: ${playerChoice}`; // Display the player's choice
    computerDisplay.textContent = `COMPUTER: ${computerChoice}`; // Display the computer's choice
    resultDisplay.textContent = result; // Display the result
    resultDisplay.classList.remove('greenText', 'redText', 'lightBlueText'); // Remove the green, red, and light blue text classes

    switch(result){ // Add the appropriate text class based on the result
        case 'Player Wins':
            resultDisplay.classList.add('greenText');
            playerScore++; // Increment the player score
            playerScoreDisplay.textContent = playerScore; // Update the player score
            break;
        case 'Computer Wins':
            resultDisplay.classList.add('redText');
            computerScore++; // Increment the computer score
            computerScoreDisplay.textContent = computerScore; // Update the computer score
            break;
        case 'Tie':
            resultDisplay.classList.add('lightBlueText');
            break;
    }
}