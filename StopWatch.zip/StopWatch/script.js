const display = document.getElementById("display");

let timer = null;
let startTime = 0;
let elapsedTime = 0;
let isRunning = false;

function startTimer() {
    if (!isRunning) {
        startTime = Date.now() - elapsedTime; // get start time
        timer = setInterval(updateTimer, 10); // start timer
        isRunning = true; // set isRunning to true
    }
}

function stopTimer() {
    if (isRunning) {
        clearInterval(timer); // stop the timer
        isRunning = false; // set isRunning to false
    }
}

function resetTimer() {
    clearInterval(timer); // stop the timer
    isRunning = false; // set isRunning to false
    elapsedTime = 0; // reset elapsed time
    updateTimer(); // update the display
}

function updateTimer() {
    const currentTime = Date.now(); // get current time
    elapsedTime = currentTime - startTime; // calculate elapsed time

    let hours = Math.floor(elapsedTime / (1000 * 60 * 60)); // calculate hours
    let minutes = Math.floor(elapsedTime / (1000 * 60) % 60); // calculate minutes
    let seconds = Math.floor(elapsedTime / 1000 % 60); // calculate seconds
    let milliseconds = Math.floor(elapsedTime / 10 % 100); // calculate milliseconds

    display.textContent = `${hours}:${minutes}:${seconds}:${milliseconds}`;
}
