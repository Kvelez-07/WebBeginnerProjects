<?php
$error_message = mysqli_connect_error();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DB ERROR</title>
</head>
<body>
    <h1>DATABASE ERROR</h1>
    <p>Database could not perform operation</p>
    <button><a href="index.php">Back</a></button>
</body>
</html>