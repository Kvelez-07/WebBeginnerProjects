<?php
session_start();
require_once('db_connect.php');
$query_students = "SELECT * FROM student ORDER BY student_id";
$student_result = mysqli_query($conn, $query_students);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Student List</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Street</th>
                <th>City</th>
                <th>State</th>
                <th>Zip</th>
                <th>Phone</th>
                <th>Birthday</th>
                <th>Sex</th>
                <th>Entered</th>
                <th>Lunch</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($student = mysqli_fetch_assoc($student_result)): ?>
                <tr>
                    <td><?php echo $student['student_id']; ?></td>
                    <td><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></td>
                    <td><?php echo $student['email']; ?></td>
                    <td><?php echo $student['street']; ?></td>
                    <td><?php echo $student['city']; ?></td>
                    <td><?php echo $student['state']; ?></td>
                    <td><?php echo $student['zip']; ?></td>
                    <td><?php echo $student['phone']; ?></td>
                    <td><?php echo $student['birth_date']; ?></td>
                    <td><?php echo $student['sex']; ?></td>
                    <td><?php echo $student['date_entered']; ?></td>
                    <td><?php echo $student['lunch_cost']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Insert Student</h2>
    <div class="user-form">
        <form action="insert_student.php" method="POST">
            <div class="form-group">
                <label for="first_name">First Name: </label>
                <input type="text" name="first_name" required><br><br>
            </div>

            <div class="form-group">
                <label for="last_name">Last Name: </label>
                <input type="text" name="last_name" required><br><br>
            </div>

            <div class="form-group">
                <label for="email">Email: </label>
                <input type="text" name="email" required><br><br>
            </div>

            <div class="form-group">
                <label for="street">Street: </label>
                <input type="text" name="street" required><br><br>
            </div> 

            <div class="form-group">
                <label for="city">City: </label>
                <input type="text" name="city" required><br><br>
            </div> 

            <div class="form-group">
                <label for="state">State: </label>
                <input type="text" name="state" required><br><br>
            </div> 

            <div class="form-group">
                <label for="zip">Zip: </label>
                <input type="text" name="zip" required><br><br>
            </div> 

            <div class="form-group">
                <label for="phone">Phone: </label>
                <input type="text" name="phone" required><br><br>
            </div> 

            <div class="form-group">
                <label for="birth_date">Birthday: </label>
                <input type="text" name="birth_date" required><br><br>
            </div> 

            <div class="form-group">
                <label for="sex">Sex: </label>
                <input type="text" name="sex" required><br><br>
            </div> 

            <div class="form-group">
                <label for="date_entered">Entered: </label>
                <input type="text" name="date_entered" required><br><br>
            </div>

            <div class="form-group">
                <label for="lunch_cost">Lunch: </label>
                <input type="text" name="lunch_cost" required><br><br>
            </div>
            <input type="submit" name="submit" value="Submit">
    </form>
    </div>
</body>
</html>