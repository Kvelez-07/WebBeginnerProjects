<?php
session_start();
include('db_connect.php');

class Student {
    private $conn; // database connection

    public function __construct($conn) {
        $this->conn = $conn; // set the database connection
    }

    public function insertStudent($data) {
        $first_name = $data['first_name'];
        $last_name = $data['last_name'];
        $email = $data['email'];
        $street = $data['street'];
        $city = $data['city'];
        $state = $data['state'];
        $zip = $data['zip'];
        $phone = $data['phone'];
        $birth_date = $data['birth_date'];
        $sex = $data['sex'];
        $date_entered = $data['date_entered'];
        $lunch_cost = $data['lunch_cost'];

        try {
            $check_query = "SELECT COUNT(*) AS count FROM student WHERE first_name = '$first_name' AND last_name = '$last_name' AND email = '$email' AND sex = '$sex'";
            $check_result = mysqli_query($this->conn, $check_query);
            $check_data = mysqli_fetch_assoc($check_result);
            if($check_data['count'] > 0) {
                echo "User already exists.";
                header("Location: db_error.php");
                exit; // or handle the error as required
            }

            // Insert user if not already exists
            $sql = "INSERT INTO student (first_name, last_name, email, street, city, state, zip, phone, birth_date, sex, date_entered, lunch_cost) VALUES ('$first_name', '$last_name', '$email', '$street', '$city', '$state', '$zip', '$phone', '$birth_date', '$sex', '$date_entered', '$lunch_cost')";
            $result = mysqli_query($this->conn, $sql);
            if(!$result) {
                echo "Error: " . mysqli_error($this->conn);
                header("Location: db_error.php");
                exit; // or handle the error as required
            }
        } catch (mysqli_sql_exception $e) {
            echo $e;
            exit; // or handle the error as required
        }

        // Redirect to index.php
        header("Location: index.php");
    }
}

if(isset($_POST['submit'])){
    $data = $_POST;
    $student = new Student($conn);
    $student->insertStudent($data);
} else {
    header("Location: db_error.php");
    exit; // or handle the error as required
}