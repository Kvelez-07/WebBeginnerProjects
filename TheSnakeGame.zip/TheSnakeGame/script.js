// speed
let speedX = 0;
let speedY = 0;

//fruit
let fruitX;
let fruitY;

// game board
let blockSize = 25;
let rows = 20;
let cols = 20; 
let board;
let context;

// game init
let isGameOver = false;

//snake length array
let serpentBody = [];

//snake specs
let serpentX = blockSize * 5;
let serpentY = blockSize * 5;

//game loop
window.onload = () => {
    board = document.getElementById("board");
    board.height = rows * blockSize;
    board.width = cols * blockSize;
    context = board.getContext("2d"); // 2d context drawing

    serveFruit(); // place the fruit on the board
    document.addEventListener("keyup", snakeOrientation); // listen to the key pressed
    setInterval(update, 1000 / 10); // multiple updates per second
}

function update() {

    if (isGameOver) {
        return; // terminate the game
    }

    context.fillStyle = 'hsl(180, 20%, 50%)';
    context.fillRect(0, 0, board.width, board.height);

    context.fillStyle = 'hsl(300, 100%, 20%)';
    context.fillRect(fruitX, fruitY, blockSize, blockSize);

    if (serpentX == fruitX && serpentY == fruitY) {
        serpentBody.push([fruitX, fruitY]); // append fruit to snake body
        serveFruit(); // place a new fruit
    }

    // draw the snake body
    for (let i = serpentBody.length - 1; i > 0; i--) {
        serpentBody[i] = serpentBody[i - 1];
    }

    // draw the snake head
    if (serpentBody.length) {
        serpentBody[0] = [serpentX, serpentY];
    }

    // generate the snake body
    serpentBody.forEach( (part) => {
        context.fillRect(part[0], part[1], blockSize, blockSize);
    });

    if (serpentX < 0 || serpentX > cols * blockSize || serpentY < 0 || serpentY > rows * blockSize) {
        isGameOver = true;
        alert("Game Over!"); // alert the user
        window.location.reload(); // reload the page
    }

    for (let i = 1; i < serpentBody.length; i++) {
        if (serpentX == serpentBody[i][0] && serpentY == serpentBody[i][1]) {
            isGameOver = true;
            alert("Game Over!");
            window.location.reload();
        }
    }

    // draw the snake head
    context.fillStyle = 'hsl(220, 100%, 30%)';
    serpentX += speedX * blockSize; // move one block in the x direction
    serpentY += speedY * blockSize; // move one block in the y direction
    context.fillRect(serpentX, serpentY, blockSize, blockSize);

}

function serveFruit() {
    // set a random position for the fruit
    fruitX = Math.floor(Math.random() * cols) * blockSize;
    fruitY = Math.floor(Math.random() * rows) * blockSize;
}

function snakeOrientation(e) {
    switch (e.code) {
        case "ArrowUp" || speedY != 1: // move in the y direction
            speedX = 0; // move in the x direction
            speedY = -1; // move in the y direction
            break;
        case "ArrowDown" || speedY != -1:
            speedX = 0;
            speedY = 1;
            break;
        case "ArrowLeft" || speedX != 1:
            speedX = -1;
            speedY = 0;
            break;
        case "ArrowRight" || speedX != -1:
            speedX = 1;
            speedY = 0;
            break;
    }
}