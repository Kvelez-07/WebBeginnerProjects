let boxes = document.querySelectorAll('.box');
let player = 'X';
let gameOver = false;

boxes.forEach(box => {
    box.innerHTML = ''; // clear the numbers in the boxes
    box.addEventListener('click', () => {
        if (!gameOver && box.innerHTML === '') {
            box.innerHTML = player;
            manageWin(); // check for win
            managePlayer(); // change player
        }
    })
});

function manageWin() {
    const winScenarios = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ]

    for (let i = 0; i < winScenarios.length; i++) {
        let a = boxes[winScenarios[i][0]];
        let b = boxes[winScenarios[i][1]];
        let c = boxes[winScenarios[i][2]];

        if (a.innerHTML === 'X' && b.innerHTML === 'X' && c.innerHTML === 'X') {
            gameOver = true;
            document.querySelector('#results').innerHTML = `${player}'s the Winner`;
            document.querySelector("#play-again").style.display = "inline-block";
            window.alert('Player X won');
        } else if (a.innerHTML === 'O' && b.innerHTML === 'O' && c.innerHTML === 'O') {
            gameOver = true;
            document.querySelector('#results').innerHTML = `${player}'s the Winner`;
            document.querySelector("#play-again").style.display = "inline-block";
            window.alert('Player O won');
        } else if (a.innerHTML !== '' && b.innerHTML !== '' && c.innerHTML !== '') {
            gameOver = true;
            document.querySelector('#results').innerHTML = "Draw";
            document.querySelector("#play-again").style.display = "inline-block";
            window.alert('Draw');
        }
    }

}

function managePlayer() {
    if (player === 'X') {
        player = 'O';
        document.querySelector('.bg').style.left = '85px'; // move the background
    } else {
        player = 'X';
        document.querySelector('.bg').style.left = '0px'; // move the background
    }
}

document.querySelector('#play-again').addEventListener('click', () => {
    window.location.reload();
})