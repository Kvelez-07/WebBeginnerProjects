﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace WinFormsCRUD.Data
{
    public class Connection
    {
        public static SqlConnection CreateConnection()
        {
            var connectionString = new SqlConnection("Data Source=.;Initial Catalog=TESTCRUD;Integrated Security=True;TrustServerCertificate=True");
            return connectionString;
        }
    }
}
