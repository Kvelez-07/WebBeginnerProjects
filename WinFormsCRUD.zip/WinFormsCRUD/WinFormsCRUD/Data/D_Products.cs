﻿using System;
using System.Data;
using System.Data.SqlClient;
using WinFormsCRUD.Entities;

namespace WinFormsCRUD.Data
{
    public class D_Products
    {
        public DataTable ProductList(string cText)
        {
            var dt = new DataTable();

            try
            {
                using (var connection = Connection.CreateConnection())
                {
                    using (var command = new SqlCommand("USP_PR_LIST", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@cText", SqlDbType.VarChar).Value = cText;

                        connection.Open();

                        using (var reader = command.ExecuteReader())
                        {
                            dt.Load(reader);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public string SaveProduct(int nOption, E_Products oPro)
        {
            string response = string.Empty;

            try
            {
                using (var connection = Connection.CreateConnection())
                {
                    using (var cmd = new SqlCommand("USP_SAVE_PR", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@nOption", SqlDbType.Int).Value = nOption;
                        cmd.Parameters.AddWithValue("@nPr_Code", SqlDbType.Int).Value = oPro.pr_code;
                        cmd.Parameters.AddWithValue("@cPr_Description", SqlDbType.VarChar).Value = oPro.pr_description;
                        cmd.Parameters.AddWithValue("@cPr_Brand", SqlDbType.VarChar).Value = oPro.pr_brand;
                        cmd.Parameters.AddWithValue("@nMe_Code", SqlDbType.Int).Value = oPro.me_code;
                        cmd.Parameters.AddWithValue("@nCa_Code", SqlDbType.Int).Value = oPro.ca_code;
                        cmd.Parameters.AddWithValue("@nCurrent_Stock", SqlDbType.Decimal).Value = oPro.current_stock;

                        connection.Open();
                        response = cmd.ExecuteNonQuery() == 1 ? "OK" : "Query wans't processed";
                    }
                }
            }
            catch (Exception ex)
            {
                response = ex.Message;
            }
            return response;
        }

        public string ActiveProduct(int nPr_Code, bool bActive_Status)
        {
            string response = string.Empty;

            try
            {
                using (var connection = Connection.CreateConnection())
                {
                    using (var cmd = new SqlCommand("USP_ACTIVE_PR", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@nPr_Code", SqlDbType.Int).Value = nPr_Code;
                        cmd.Parameters.AddWithValue("@bActive_Status", SqlDbType.Bit).Value = bActive_Status;

                        connection.Open();
                        response = cmd.ExecuteNonQuery() == 1 ? "OK" : "Query wans't processed";
                    }
                }
            }
            catch (Exception ex)
            {
                response = ex.Message;
            }
            return response;
        }

        public DataTable MeasureList()
        {
            var dt = new DataTable();

            try
            {
                using (var connection = Connection.CreateConnection())
                {
                    using (var command = new SqlCommand("USP_ME_LIST", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        connection.Open();

                        using (var reader = command.ExecuteReader())
                        {
                            dt.Load(reader);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public DataTable CategoryList()
        {
            var dt = new DataTable();

            try
            {
                using (var connection = Connection.CreateConnection())
                {
                    using (var command = new SqlCommand("USP_CA_LIST", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        connection.Open();

                        using (var reader = command.ExecuteReader())
                        {
                            dt.Load(reader);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public string DeleteProduct(int nPr_Code)
        {
            string response = string.Empty;

            try
            {
                using (var connection = Connection.CreateConnection())
                {
                    using (var cmd = new SqlCommand("USP_DELETE_PR", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@nPr_Code", SqlDbType.Int).Value = nPr_Code;

                        connection.Open();
                        response = cmd.ExecuteNonQuery() == 1 ? "OK" : "Query wasn't processed";
                    }
                }
            }
            catch (Exception ex)
            {
                response = ex.Message;
            }
            return response;
        }
    }
}
