﻿using System;

namespace WinFormsCRUD.Entities
{
    public class E_Products
    {
        public int pr_code { get; set; }
        public string pr_description { get; set; }
        public string pr_brand { get; set; }
        public int me_code { get; set; }
        public int ca_code { get; set; }
        public decimal current_stock { get; set; }
        public DateTime created_at { get; set; }
        public int active { get; set; }
    }
}
