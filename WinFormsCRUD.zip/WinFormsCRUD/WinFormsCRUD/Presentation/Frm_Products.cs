﻿using System;
using System.Windows.Forms;
using WinFormsCRUD.Data;
using WinFormsCRUD.Entities;

namespace WinFormsCRUD.Presentation
{
    public partial class Frm_Products : Form
    {
        public Frm_Products()
        {
            InitializeComponent();
        }

        #region "Variables"
        int saveStatus = 0;
        int vProduct_Code = 0; // v = variable
        #endregion

        #region "Methods"
        private void ClearFields()
        {
            productTxt.Text = string.Empty;
            brandTxt.Text = string.Empty;
            measureCombo.Text = string.Empty;
            categoryCombo.Text = string.Empty;
            stockTxt.Text = string.Empty;
        }

        private void TextStatus(bool status)
        {
            productTxt.Enabled = status;
            brandTxt.Enabled = status;
            measureCombo.Enabled = status;
            categoryCombo.Enabled = status;
            stockTxt.Enabled = status;
        }

        private void ButtonStatus(bool status)
        {
            saveButton.Visible = !status;
            cancelButton.Visible = !status;

            newButton.Visible = status;
            editButton.Visible = status;
            deleteButton.Visible = status;
            reportButton.Visible = status;
            exitButton.Visible = status;

            searchButton.Visible = status;
            searchTxt.Enabled = status;
            productGrid.Enabled = status;
        }

        private void LoadMeasure()
        {
            var data = new D_Products();
            measureCombo.DataSource = data.MeasureList();
            measureCombo.ValueMember = "me_code";
            measureCombo.DisplayMember = "me_description";
        }

        private void LoadCategory()
        {
            var data = new D_Products();
            categoryCombo.DataSource = data.CategoryList();
            categoryCombo.ValueMember = "ca_code";
            categoryCombo.DisplayMember = "ca_description";
        }

        private void ProductFormat()
        {
            productGrid.Columns[0].Width = 90;
            productGrid.Columns[0].HeaderText = "Code";
            productGrid.Columns[1].Width = 210;
            productGrid.Columns[1].HeaderText = "Description";
            productGrid.Columns[2].Width = 110;
            productGrid.Columns[2].HeaderText = "Brand";
            productGrid.Columns[3].Width = 110;
            productGrid.Columns[3].HeaderText = "Measure";
            productGrid.Columns[4].Width = 110;
            productGrid.Columns[4].HeaderText = "Category";
            productGrid.Columns[5].Width = 110;
            productGrid.Columns[5].HeaderText = "Stock";
            productGrid.Columns[6].Visible = false; // Hide the measure code
            productGrid.Columns[7].Visible = false; // Hide the category code
        }

        private void LoadProduct(string cText)
        {
            productGrid.DataSource = new D_Products().ProductList(cText); // Load the product list
            ProductFormat(); // Format the grid
        }

        private void ProductItemSelect()
        {
            if (Convert.ToString(productGrid.CurrentRow.Cells["pr_code"].Value) == null)
            {
                MessageBox.Show("No records found in the grid.", 
                    "Warning: ",
                    MessageBoxButtons.OK, // button type
                    MessageBoxIcon.Exclamation); // alert icon
            }
            else
            {
                vProduct_Code = Convert.ToInt32(productGrid.CurrentRow.Cells["pr_code"].Value);
                productTxt.Text = Convert.ToString(productGrid.CurrentRow.Cells["pr_description"].Value);
                brandTxt.Text = Convert.ToString(productGrid.CurrentRow.Cells["pr_brand"].Value);
                measureCombo.Text = Convert.ToString(productGrid.CurrentRow.Cells["me_description"].Value);
                categoryCombo.Text = Convert.ToString(productGrid.CurrentRow.Cells["ca_description"].Value);
                stockTxt.Text = Convert.ToString(productGrid.CurrentRow.Cells["current_stock"].Value);
            }
        }
        #endregion

        private void newButton_Click(object sender, EventArgs e)
        {
            saveStatus = 1; // Save status = New Record
            vProduct_Code = 0; // Reset the product code
            ClearFields();
            TextStatus(true);
            ButtonStatus(false);
            productTxt.Select();
        }

        private void Frm_Products_Load(object sender, EventArgs e)
        {
            LoadMeasure(); // Load the measure combo box
            LoadCategory(); // Load the category combo box
            LoadProduct("%"); // Load all from the product list
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            ClearFields();
            TextStatus(false);
            ButtonStatus(true);
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            // Validate the fields
            if (productTxt.Text == string.Empty ||
                brandTxt.Text == string.Empty ||
                measureCombo.Text == string.Empty ||
                categoryCombo.Text == string.Empty ||
                stockTxt.Text == string.Empty)
            {
                MessageBox.Show("Missing (*) data.", 
                    "Warning: ",
                    MessageBoxButtons.OK, // button type
                    MessageBoxIcon.Exclamation); // alert icon
            }
            else
            {
                string response = string.Empty;
                var oProduct = new E_Products(); // Create a new product object
                oProduct.pr_code = vProduct_Code; // Product code
                oProduct.pr_description = productTxt.Text;
                oProduct.pr_brand = brandTxt.Text;
                oProduct.me_code = Convert.ToInt32(measureCombo.SelectedValue); // measure code conversion
                oProduct.ca_code = Convert.ToInt32(categoryCombo.SelectedValue); // category code conversion
                oProduct.current_stock = Convert.ToDecimal(stockTxt.Text);

                var data = new D_Products(); // Create a new product data object
                response = data.SaveProduct(saveStatus, oProduct); // Save with either 1 = New or 2 = Edit

                if (response == "OK")
                {
                    MessageBox.Show("Record saved successfully.", 
                        "Information: ",
                        MessageBoxButtons.OK, // button type
                        MessageBoxIcon.Information); // alert icon
                        vProduct_Code = 0; // Reset the product code
                        ClearFields();
                        TextStatus(false); // Disable the fields
                        ButtonStatus(true); // Enable the buttons
                        LoadProduct("%");
                }
                else
                {
                    MessageBox.Show(response, 
                        "Error: ",
                        MessageBoxButtons.OK, // button type
                        MessageBoxIcon.Error); // alert icon
                }
            }
        }

        private void productGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductItemSelect();
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            saveStatus = 2; // Save status = Edit Record
            TextStatus(true);
            ButtonStatus(false);
            productTxt.Select();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            LoadProduct(searchTxt.Text);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (vProduct_Code == 0)
            {
                MessageBox.Show("Please select a product to delete.",
                    "Warning: ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                return;
            }

            var result = MessageBox.Show("Are you sure you want to delete this product?",
                "Confirm Deletion",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                var data = new D_Products();
                string response = data.DeleteProduct(vProduct_Code);

                if (response == "OK")
                {
                    MessageBox.Show("Product deleted successfully.",
                        "Information: ",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    vProduct_Code = 0;
                    ClearFields();
                    LoadProduct("%");
                }
                else
                {
                    MessageBox.Show(response,
                        "Error: ",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }
    }
}
