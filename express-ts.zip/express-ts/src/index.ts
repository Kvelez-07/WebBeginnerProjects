import express from 'express';
import diariesRouter from './routes/diaryRouter';

const app: express.Application = express();
const port: number = 3000;

const users = [
    { id: 1, name: 'John' },
    { id: 2, name: 'Jane' }
]

app.use(express.json());

app.get('/', (req: express.Request, res: express.Response) => {
    res.send('Hello, World!');
});

app.get('/users', (req: express.Request, res: express.Response) => {
    res.send(users);
});

app.use('/diaries', diariesRouter);

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
})