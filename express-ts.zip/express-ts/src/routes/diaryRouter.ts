import express from 'express';

const router: express.Router = express.Router();

router.get('/', (req: express.Request, res: express.Response) => {
    res.send('Fetching diaries...');
})

router.post('/', (req: express.Request, res: express.Response) => {
    res.send('Saving a diary...');
})

export default router;