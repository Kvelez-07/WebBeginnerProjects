console.log("Hello, World!");
alert("Hello, World!");