<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP + TS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-MlbWIR36iYmjFJh43bzRNudZR2xMHf5kg+FOiJ5pGnNjKiEdAUp/FrVz4wg90zDn" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/style.css">
    <script defer src="../js/script.js"></script>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
</head>
<body>
    <header class="lyrics-header">
        <h1>Think About You</h1>
        <h4>Guns N' Roses</h4>
        <a href="https://youtu.be/0bjPk-wmfRQ?si=f0he66EEKY_gq1fE">Original Video</a><br>

        <img src="../img/album.jpg" alt="appetite for destruction - album cover">

        <div class="lyrics-audio">
            <audio controls autoplay muted loop>
                <source src="../audio/ThinkAboutYou.mp3" type="audio/mpeg">
                <source src="../audio/ThinkAboutYou.wav" type="audio/wav">
            </audio>
        </div>
    </header>
    <hr>

    <pre class="lyrics-container">
        Cha! I said, “Baby, you been lookin' real good”
        You know that I remember when we met
        It's funny how I never felt so good
        It's a feelin' that I know, I know I'll never forget

        [Bridge]
        Ooh, it was the best time I can remember
        Ooh, and the love we shared
        Lovin' that'll last forever

        [Verse 2]
        Ow, there wasn't much in this heart of mine
        There was a little left, and, babe, you found it
        It's funny how I never felt so high
        It's a feeling that I know, I know I'll never forget

        [Pre-Chorus]
        Ooh, it was the best time I can remember
        Ooh, and the love we shared
        Lovin' that'll last forever

        [Chorus]
        I think about you, honey, all the time, my heart says, “Yes”
        I think about you, deep inside, I love you best
        I think about you, you know you're the one I want
        I think about you, darling, you're the only one
        I think about you, yeah!
        Hahaha!
        [Guitar solo]

        [Post-Chorus]
        I think about you, you know that I do
        I think about you, all alone, only you
        I think about you, ooh-oh, it's true
        I think about you, oh, yes, I do

        [Verse 3]
        Somethin' changed in this heart of mine
        You know that I'm so glad that you showed me
        Honey, now you're my best friend
        I wanna stay together till the very end

        [Pre-Chorus]
        Ooh, it was the best time I can remember
        Ooh, and the love we shared
        Lovin' that'll last forever

        [Chorus]
        I think about you, honey, all the time, my heart says, “Yes”
        I think about you, deep inside, I love you best
        I think about you, you know you're the one I want
        I think about you, darling, you're the only one

        [Outro]
        I think about you, oh-oh yeah
        I think about you, oh you
        I think about you
        Only you
        I think about you, you know I do
        I think about you, only you
        I think about you
        Only you
        Only
        You
        Only
    </pre>
    
    <div class="lyrics-video">
        <a href="https://youtu.be/0bjPk-wmfRQ?si=f0he66EEKY_gq1fE">
            <video controls autoplay muted loop>
                <source src="../video/ThinkAboutYou.mp4" type="video/mp4">
                <source src="../video/ThinkAboutYou.webm" type="video/webm">
            </video>
        </a>
    </div>
    <hr>

    <footer class="lyrics-footer">
        <p>Lyrics - Copyright © 2024</p>
    </footer>
</body>
</html>