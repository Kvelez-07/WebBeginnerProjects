<?php

session_start();
require_once "database.php";

if(isset($_REQUEST['submit'])) {
    $name = filter_var($_REQUEST['name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_REQUEST['email'], FILTER_SANITIZE_EMAIL);
    $password = filter_var($_REQUEST['password'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "SELECT * FROM users WHERE email = :email AND name = :name";
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':email', $email);
    $stmt->bindValue(':name', $name);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user) {
        $_SESSION['name'] = $user['name'];
        $_SESSION['email'] = $user['email'];
    } else {
        $_SESSION['error'] = "<br> User $_REQUEST[name] not found";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>View User</h1>
        <form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" method="POST">
            <input type="text" name="name" placeholder="name">
            <input type="text" name="email" placeholder="email">
            <input type="text" name="password" placeholder="password">
            <input type="submit" name="submit" value="submit">
        </form><br>

        <h2>Welcome</h2>
        <h4>User: <?php if(isset($_SESSION['name'])) echo $_SESSION['name']; ?></h4>
        <h4>Email: <?php if(isset($_SESSION['email'])) echo $_SESSION['email']; ?></h4>
        <p><?php if(isset($_SESSION['error'])) echo $_SESSION['error']; ?></p>
        <a href="index.php">Back</a>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>