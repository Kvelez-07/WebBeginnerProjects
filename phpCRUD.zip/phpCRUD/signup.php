<?php

require_once "database.php";

if(isset($_REQUEST['submit'])) {
    $name = filter_var($_REQUEST['name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_REQUEST['email'], FILTER_SANITIZE_EMAIL);
    $password = filter_var($_REQUEST['password'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name, email, password, created) VALUES (:name, :email, :password, :created)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $password);
    $created = new DateTime();
    $created = $created->format('Y-m-d H:i:s');
    $stmt->bindParam(':created', $created);
    $stmt->execute();

    header("Location: index.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h1>Create User</h1>
        <form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" method="POST">
            <input type="text" name="name" placeholder="name">
            <input type="text" name="email" placeholder="email">
            <input type="text" name="password" placeholder="password">
            <input type="submit" name="submit" value="submit">
        </form>
    </div>
</body>
</html>