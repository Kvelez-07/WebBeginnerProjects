<?php
session_start();
include("db_connection.php");

if(isset($_POST['submit'])){
    $fruit_name = $_POST['fruit_name'];
    $price = $_POST['price'];
    $_SESSION['fruit_name'] = $fruit_name;
    $_SESSION['price'] = $price;

    $sql = "SELECT * FROM fruit WHERE fruit_name = '$fruit_name'";
    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Enter new fruit</h1>

    <form action="./index.php" method="post">
        <label for="fruit_name">Fruit:</label>
        <input type="text" name="fruit_name"> <br> <br>
        <label for="price">Price:</label>
        <input type="number" name="price">
        <input type="submit" name="submit" value="Submit">
    </form>
    
    <h2>Fruits</h2>
    <?php
        if($result->num_rows > 0){
            echo "<ul>";
            while($row = $result->fetch_assoc()){
                echo "<li>" . "Fruit: " . $row["fruit_name"] . ", Price: " . $row["price"] . "</li>";
            }
            echo "</ul>";
        }else{
            echo "0 results";
        }
    ?>
</body>
</html>
