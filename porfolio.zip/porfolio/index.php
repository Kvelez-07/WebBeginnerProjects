<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kevin Vélez - Portfolio</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./css/styles.css">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <header>
        <h1 class="fade-in">Kvelez07</h1>
        <nav>
            <a class="darkerText" href="https://github.com/Kvelez-07" target="_blank" rel="noopener noreferrer">Github</a>
            <a class="darkerText" href="https://www.linkedin.com/in/kevin-v%C3%A9lez-salazar-65a942200/" target="_blank" rel="noopener noreferrer">LinkedIn</a>
        </nav>
    </header>
    <main>
        <section>
            <div class="nameContainer">
                <h1 class="fade-in name">Kevin Vélez Salazar</h1>
                <p class="darkerText fade-in subtitle">Junior PHP and .NET Web Developer</p>
            </div>
            <div class="statsContainer">
                <div class="imgContainer">
                    <img src="https://media.licdn.com/dms/image/v2/D4D35AQEEGzf0Ax0PJg/profile-framedphoto-shrink_400_400/profile-framedphoto-shrink_400_400/0/1706024346921?e=1728604800&v=beta&t=oO39IrDi4w1X-dJRhVdTYM4FK3QQrEJvjTonB2_vdng" alt="profile-img">
                </div>
                <div class="stats fade-in">
                    <div>
                        <i class="fa-solid fa-check"></i>
                        <p class="darkerText">6 Github Repositories</p>
                    </div>
                    <div>
                        <i class="fa-brands fa-github"></i>
                        <p class="darkerText">9 followers</p>
                    </div>
                    <div>
                        <i class="fa-solid fa-chart-simple"></i>
                        <p class="darkerText">77 commits this year</p>
                    </div>
                </div>
                <div class="about fade-in">
                    <p class="aboutMe">
                        Hi, I'm Kevin Velez, a software engineer passionate about web development.
                        I'm currently seeking a full-time web developer position. Let's build something great together!
                    </p>
                </div>
                <div class="fade-in">
                    <a href="mailto:youremail@example.com" class="outReach darkerText">
                        <i class="fa-solid fa-arrow-right"></i>
                        <p>Email Me</p>
                    </a>
                </div>
            </div>
        </section>
        <section class="projectContainer">
            <p class="darkerText headerText fade-in">Latest Projects</p>
            <div class="projectItem fade-in">
                <div>
                    <p class="darkerText">Jan 24, 2024</p>
                    <p>ASP.NET Framework Shop for buying tech devices.</p>
                </div>
                <div>
                    <img src="./img/aspNetShop.jpg" alt="asp.net framework shop">
                </div>
            </div>
        </section>
    </main>
</body>
</html>