import Card from "./components/Card";
import List from "./components/List";
import Title from "./components/Title";

export default function App()
{
  const dataList: string[] = ["Goku", "Vegeta", "Trunks"];
  return (
    <div className="container">
      <Title />
      <Card children="Sample Text" />
      <List data={dataList} />
    </div>
  )
}
