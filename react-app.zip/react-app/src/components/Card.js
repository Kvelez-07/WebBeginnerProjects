"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Card;
const CardBody_1 = __importDefault(require("./CardBody"));
function Card(props) {
    const { children: body } = props; // destructuring
    return (<div className="mb-4">
            <div className="card" style={{ width: '18rem' }}>
                <div className="card-body">
                    <CardBody_1.default title="Card title" text={body}/>
                </div>
            </div>
        </div>);
}
