import { ReactNode } from "react";
import CardBody from "./CardBody";

interface CardProps
{
    children: ReactNode;
}

export default function Card(props: CardProps)
{
    const { children: body } = props; // destructuring
    return (
        <div className="mb-4">
            <div className="card" style={{ width: '18rem' }}>
                <div className="card-body">
                    <CardBody title="Card title" text={body} />
                </div>
            </div>
        </div>
    )
}