import { ReactNode } from "react";

interface CardBodyProps
{
    title: string;
    text: string|ReactNode;
}

export default function CardBody(props: CardBodyProps)
{
    const { title, text } = props; // destructuring
    return (
        <>
            <h5 className="card-title">{title}</h5>
            <p className="card-text">{text}</p>
            {/* <a href="#" className="btn btn-primary">Go somewhere</a> */}
        </>
    )
}