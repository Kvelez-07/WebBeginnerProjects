import React, { useState } from 'react';

interface ListProps
{
    data: string[];
}

export default function List(props: ListProps)
{
    const { data } = props;
    const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

    const handleClick = (event: React.MouseEvent<HTMLLIElement>) =>
    {
        console.log(event.currentTarget.textContent);
    };

    const handleHover = (index: number) =>
    {
        setHoveredIndex(index);
    };

    return (
        <div>
            <h2>List</h2>
            <ul className="list-group">
                {data.map((item, index) => (
                    <li
                        onMouseEnter={() => handleHover(index)}
                        onClick={handleClick}
                        key={item}
                        className={`list-group-item ${hoveredIndex === index ? 'active' : ''}`}
                    >
                        {item}
                    </li>
                ))}
            </ul>
        </div>
    );
}
