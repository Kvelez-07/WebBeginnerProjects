"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Title;
const react_1 = require("react");
function Title() {
    const username = 'Kvelez07';
    const [isActive, setIsActive] = (0, react_1.useState)(false);
    const handleIsActiveToggle = () => {
        setIsActive(!isActive);
    };
    return (<div>
            <h1>{isActive ? `Hello ${username}` : 'Hello World'}</h1>
            <button className='mb-4' onClick={handleIsActiveToggle}>Toggle</button>
        </div>);
}
