import { useState } from 'react'

export default function Title()
{
    const username: string = 'Kvelez07';
    const [isActive, setIsActive] = useState(false);

    const handleIsActiveToggle = () =>
    {
        setIsActive(!isActive);
    };

    return (
        <div>
            <h1>{isActive ? `Hello ${username}` : 'Hello World'}</h1>
            <button className='mb-4' onClick={handleIsActiveToggle}>Toggle</button>
        </div>
    );
}
